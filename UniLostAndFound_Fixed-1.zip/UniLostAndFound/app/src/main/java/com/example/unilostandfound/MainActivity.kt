package com.example.unilostandfound

import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.Menu
import android.view.MenuItem
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.chip.ChipGroup
import com.google.android.material.floatingactionbutton.ExtendedFloatingActionButton
import com.google.firebase.firestore.ListenerRegistration

class MainActivity : BaseActivity() {
    private lateinit var adapter: PostAdapter
    private lateinit var etSearch: EditText
    private lateinit var tvStats: TextView
    private lateinit var tvEmpty: TextView
    private var filter = "all"
    private var allPosts: List<Post> = emptyList()
    private var reg: ListenerRegistration? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Session.user == null) {
            startActivity(Intent(this, LoginActivity::class.java)); finish(); return
        }
        setContentView(R.layout.activity_main)
        setSupportActionBar(findViewById<Toolbar>(R.id.toolbar))

        etSearch = findViewById(R.id.etSearch)
        tvStats = findViewById(R.id.tvStats)
        tvEmpty = findViewById(R.id.tvEmpty)

        adapter = PostAdapter { post ->
            startActivity(Intent(this, PostDetailActivity::class.java).putExtra("id", post.id))
        }
        findViewById<RecyclerView>(R.id.rvPosts).apply {
            layoutManager = LinearLayoutManager(this@MainActivity)
            adapter = this@MainActivity.adapter
        }

        findViewById<ChipGroup>(R.id.chipGroup).setOnCheckedStateChangeListener { _, ids ->
            filter = when (ids.firstOrNull()) {
                R.id.chipLost -> TYPE_LOST
                R.id.chipFound -> TYPE_FOUND
                R.id.chipDone -> ST_DONE
                else -> "all"
            }
            render()
        }
        etSearch.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) { render() }
            override fun afterTextChanged(s: Editable?) {}
        })
        findViewById<ExtendedFloatingActionButton>(R.id.fabAdd).setOnClickListener {
            startActivity(Intent(this, AddPostActivity::class.java))
        }
    }

    override fun onStart() {
        super.onStart()
        if (!::adapter.isInitialized) return
        // تحديث مباشر: أي بلاغ جديد من أي طالب بيظهر هنا علطول
        reg = Repo.listenPosts { list -> allPosts = list; render() }
    }

    override fun onStop() {
        reg?.remove(); reg = null
        super.onStop()
    }

    private fun render() {
        val q = etSearch.text.toString().trim()
        val list = allPosts.filter { p ->
            val okFilter = when (filter) {
                "all" -> true
                ST_DONE -> p.status == ST_DONE
                else -> p.type == filter && p.status == ST_OPEN
            }
            val hay = "${p.title} ${p.category} ${p.location} ${p.description} ${p.authorName}"
            okFilter && hay.contains(q, ignoreCase = true)
        }.sortedWith(compareBy<Post> { it.status == ST_DONE }.thenByDescending { it.createdAt })

        adapter.submit(list)
        tvEmpty.show(list.isEmpty())
        val open = allPosts.count { it.status == ST_OPEN }
        tvStats.text = "$open بلاغ مفتوح  •  ${allPosts.size - open} اتسلّم"
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.menu_main, menu); return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.action_settings -> startActivity(Intent(this, SettingsActivity::class.java))
            R.id.action_about -> showAbout(this)
            R.id.action_logout -> confirmLogout(this)
        }
        return true
    }
}

fun showAbout(a: AppCompatActivity) {
    AlertDialog.Builder(a)
        .setTitle("مفقودات جامعة النيل 🎓")
        .setMessage("أي حاجة ضاعت منك داخل الجامعة، بلّغ عنها هنا. وأي حاجة لقيتها، انشرها عشان توصل لصاحبها.\n\nكل طلاب الجامعة بيشوفوا البلاغات. صاحب الغرض بيتواصل مع الناشر، بيتأكد منو، وبعد الاستلام بيضغط «تأكيد الاستلام».")
        .setPositiveButton("تمام", null).show()
}

fun confirmLogout(a: AppCompatActivity) {
    AlertDialog.Builder(a)
        .setTitle("تسجيل خروج")
        .setMessage("متأكد عايز تطلع؟ (البصمة بتتعطّل وبتحتاج تفعّلها تاني بعد ما تدخل)")
        .setNegativeButton("لا", null)
        .setPositiveButton("أيوا، اطلع") { _, _ ->
            Repo.signOut()
            a.startActivity(Intent(a, LoginActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK))
        }.show()
}
