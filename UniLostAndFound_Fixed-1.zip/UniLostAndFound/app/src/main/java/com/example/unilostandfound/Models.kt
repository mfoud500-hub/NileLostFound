package com.example.unilostandfound

import com.google.firebase.firestore.DocumentSnapshot

const val TYPE_LOST = "lost"
const val TYPE_FOUND = "found"
const val ST_OPEN = "open"
const val ST_DONE = "done"

data class User(val id: String, val name: String, val studentNo: String, val phone: String)

/** المستخدم الحالي في الذاكرة بعد تسجيل الدخول. */
object Session { var user: User? = null }

data class Post(
    val id: String, val authorId: String, val authorName: String, val authorPhone: String,
    val type: String, val title: String, val category: String, val location: String,
    val createdAt: Long, val description: String, val photoB64: String,
    var status: String = ST_OPEN, var receivedBy: String = "", var receivedAt: Long = 0L
) {
    fun toMap(): Map<String, Any> = hashMapOf(
        "authorId" to authorId, "authorName" to authorName, "authorPhone" to authorPhone,
        "type" to type, "title" to title, "category" to category, "location" to location,
        "createdAt" to createdAt, "description" to description, "photoB64" to photoB64,
        "status" to status, "receivedBy" to receivedBy, "receivedAt" to receivedAt
    )

    companion object {
        fun from(d: DocumentSnapshot): Post? {
            val title = d.getString("title") ?: return null
            return Post(
                d.id, d.getString("authorId") ?: "", d.getString("authorName") ?: "",
                d.getString("authorPhone") ?: "", d.getString("type") ?: TYPE_LOST, title,
                d.getString("category") ?: "", d.getString("location") ?: "",
                d.getLong("createdAt") ?: 0L, d.getString("description") ?: "",
                d.getString("photoB64") ?: "", d.getString("status") ?: ST_OPEN,
                d.getString("receivedBy") ?: "", d.getLong("receivedAt") ?: 0L
            )
        }
    }
}
