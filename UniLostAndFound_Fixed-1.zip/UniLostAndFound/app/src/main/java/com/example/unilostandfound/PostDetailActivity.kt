package com.example.unilostandfound

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.widget.Toolbar
import com.google.android.material.button.MaterialButton
import com.google.firebase.firestore.ListenerRegistration

class PostDetailActivity : BaseActivity() {
    private var postId = ""
    private var post: Post? = null
    private lateinit var me: User
    private var reg: ListenerRegistration? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val u = Session.user
        val id = intent.getStringExtra("id")
        if (u == null || id == null) { finish(); return }
        me = u; postId = id
        setContentView(R.layout.activity_post_detail)
        val tb = findViewById<Toolbar>(R.id.toolbar)
        setSupportActionBar(tb)
        tb.setNavigationOnClickListener { finish() }
    }

    override fun onStart() {
        super.onStart()
        if (postId.isEmpty()) return
        reg = Repo.listenPost(postId) { p ->
            if (p == null) { finish() } else { post = p; invalidateOptionsMenu(); bind(p) }
        }
    }

    override fun onStop() {
        reg?.remove(); reg = null
        super.onStop()
    }

    private fun isAuthor(p: Post) = p.authorId == me.id

    /** مين يقدر يضغط «تأكيد الاستلام»؟ صاحب الغرض بس. */
    private fun canConfirm(p: Post): Boolean {
        if (p.status != ST_OPEN) return false
        return if (p.type == TYPE_FOUND) p.authorId != me.id   // الناشر لقاه، المستلم هو صاحبو
        else p.authorId == me.id                                // الناشر هو صاحب الغرض الضايع
    }

    private fun bind(post: Post) {
        val ivPhoto = findViewById<ImageView>(R.id.ivPhoto)
        if (post.photoB64.isNotBlank()) {
            ivPhoto.show(true); ImageLoader.loadB64(ivPhoto, post.id, post.photoB64)
        } else ivPhoto.show(false)

        val badge = findViewById<TextView>(R.id.tvBadge)
        badge.text = typeLabel(post.type)
        if (post.type == TYPE_LOST) {
            badge.setBackgroundResource(R.drawable.bg_badge_lost); badge.setTextColor(getColor(R.color.ink))
        } else {
            badge.setBackgroundResource(R.drawable.bg_badge_found); badge.setTextColor(getColor(R.color.blue_dark))
        }
        findViewById<TextView>(R.id.tvTitle).text = post.title
        findViewById<TextView>(R.id.tvInfo).text =
            "🏷️ ${post.category}\n📍 ${post.location}\n🕒 ${fullDate(post.createdAt)}  (${timeAgo(post.createdAt)})"
        val desc = findViewById<TextView>(R.id.tvDesc)
        desc.text = post.description
        desc.show(post.description.isNotBlank())

        findViewById<TextView>(R.id.tvAvatar).text = post.authorName.trim().take(1).ifEmpty { "؟" }
        findViewById<TextView>(R.id.tvAuthor).text = post.authorName + if (isAuthor(post)) "  (إنت)" else ""
        val hasPhone = post.authorPhone.filter { it.isDigit() }.length >= 9
        findViewById<TextView>(R.id.tvPhone).text =
            if (hasPhone) post.authorPhone else "تواصل معاهم في مكتب شؤون الطلاب"
        findViewById<android.view.View>(R.id.contactRow).show(hasPhone && !isAuthor(post))

        findViewById<MaterialButton>(R.id.btnCall).setOnClickListener {
            startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:${post.authorPhone}")))
        }
        findViewById<MaterialButton>(R.id.btnWhatsApp).setOnClickListener {
            val msg = "السلام عليكم، أنا ${me.name} من تطبيق مفقودات جامعة النيل. بخصوص: ${post.title}"
            val url = "https://wa.me/${waNumber(post.authorPhone)}?text=${Uri.encode(msg)}"
            try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) }
            catch (e: Exception) { toast("ما قدرنا نفتح واتساب") }
        }

        val tip = findViewById<TextView>(R.id.tvTip)
        tip.text = when {
            post.status == ST_DONE -> "البلاغ دا خلص ✔️"
            isAuthor(post) && post.type == TYPE_LOST ->
                "الإعلان دا إنت نشرتو. لمّا غرضك يرجع ليك اضغط «تأكيد الاستلام» تحت."
            isAuthor(post) ->
                "الإعلان دا إنت نشرتو. لمّا صاحب الغرض يستلمو بيضغط «تأكيد الاستلام» وإنت بتشوف الحالة هنا."
            post.type == TYPE_FOUND ->
                "دا بتاعك؟ كلّم الناشر وصّف ليهو الغرض وعلامة مميزة فيهو (لون، ماركة، شنو جواهو)، وقابلو جوّه الجامعة. بعد ما تستلم اضغط «تأكيد الاستلام»."
            else ->
                "لقيت الغرض؟ كلّم صاحبو واتأكد إنو بيوصّفو صاح قبل ما تسلّمو. بعد التسليم هو بيضغط «تأكيد الاستلام»."
        }
        tip.show(post.status == ST_OPEN)

        val done = findViewById<TextView>(R.id.tvDone)
        if (post.status == ST_DONE) {
            done.show(true)
            done.text = "✅ اتسلّم" + (if (post.receivedBy.isNotBlank()) " لـ ${post.receivedBy}" else "") +
                (if (post.receivedAt > 0) "\n${fullDate(post.receivedAt)}" else "")
        } else done.show(false)

        val btn = findViewById<MaterialButton>(R.id.btnConfirm)
        btn.show(canConfirm(post))
        btn.setOnClickListener {
            AlertDialog.Builder(this)
                .setTitle("تأكيد الاستلام ✅")
                .setMessage("إنت استلمت الغرض فعلاً وتأكدت إنو بتاعك؟ بعد التأكيد البلاغ بيتقفل.")
                .setNegativeButton("لسّه", null)
                .setPositiveButton("أيوا، استلمت") { _, _ ->
                    btn.isEnabled = false
                    Repo.confirmReceipt(post.id, me) { ok ->
                        btn.isEnabled = true
                        toast(if (ok) "الحمد لله، اتأكد الاستلام 🎉" else "ما قدرنا نأكّد، اتأكد من النت وجرّب تاني")
                    }
                }.show()
        }
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        val p = post
        if (p != null && isAuthor(p)) menuInflater.inflate(R.menu.menu_detail, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == R.id.action_delete) {
            AlertDialog.Builder(this)
                .setTitle("مسح البلاغ")
                .setMessage("عايز تمسح البلاغ دا؟")
                .setNegativeButton("لا", null)
                .setPositiveButton("امسحو") { _, _ -> Repo.deletePost(postId); finish() }
                .show()
            return true
        }
        return super.onOptionsItemSelected(item)
    }
}
