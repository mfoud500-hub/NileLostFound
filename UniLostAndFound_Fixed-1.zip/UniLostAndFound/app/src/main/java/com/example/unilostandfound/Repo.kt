package com.example.unilostandfound

import android.content.Context
import com.google.firebase.FirebaseNetworkException
import com.google.firebase.FirebaseTooManyRequestsException
import com.google.firebase.auth.EmailAuthProvider
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException
import com.google.firebase.auth.FirebaseAuthInvalidUserException
import com.google.firebase.auth.FirebaseAuthUserCollisionException
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.Query

/** كل الاتصال بـ Firebase (الحسابات + البلاغات) في مكان واحد. */
object Repo {
    private var ctx: Context? = null
    fun init(c: Context) { if (ctx == null) ctx = c.applicationContext }

    private val auth get() = FirebaseAuth.getInstance()
    private val db get() = FirebaseFirestore.getInstance()
    private val prefs get() = ctx!!.getSharedPreferences("unilf_local", Context.MODE_PRIVATE)

    /** الرقم الجامعي بيتحوّل لإيميل داخلي عشان نستخدم Firebase Auth. */
    private fun email(studentNo: String) = "$studentNo@nileuni.app"

    private fun errMsg(e: Exception): String = when (e) {
        is FirebaseAuthUserCollisionException -> "الرقم الجامعي دا مسجّل من قبل"
        is FirebaseAuthInvalidCredentialsException, is FirebaseAuthInvalidUserException ->
            "الرقم الجامعي أو كلمة السر ما صاح يا زول"
        is FirebaseNetworkException -> "ما في نت، اتأكد من الاتصال"
        is FirebaseTooManyRequestsException -> "محاولات كتيرة، استنى شوية وجرّب"
        else -> "حصل خطأ: ${e.message}"
    }

    // ---------- الحسابات ----------
    fun register(name: String, sno: String, phone: String, pw: String, cb: (User?, String?) -> Unit) {
        auth.createUserWithEmailAndPassword(email(sno), pw)
            .addOnSuccessListener { r ->
                val uid = r.user!!.uid
                val u = User(uid, name, sno, phone)
                db.collection("users").document(uid)
                    .set(mapOf("name" to name, "studentNo" to sno, "phone" to phone))
                    .addOnSuccessListener { Session.user = u; cb(u, null) }
                    .addOnFailureListener { cb(null, "اتسجّل الحساب لكن ما اتحفظت بياناتك، جرّب تدخل تاني") }
            }
            .addOnFailureListener { cb(null, errMsg(it)) }
    }

    fun login(sno: String, pw: String, cb: (User?, String?) -> Unit) {
        auth.signInWithEmailAndPassword(email(sno), pw)
            .addOnSuccessListener { r ->
                loadUser(r.user!!.uid) { u ->
                    if (u == null) cb(null, "ما لقينا بيانات الحساب، جرّب تاني")
                    else { Session.user = u; cb(u, null) }
                }
            }
            .addOnFailureListener { cb(null, errMsg(it)) }
    }

    fun loadUser(uid: String, cb: (User?) -> Unit) {
        db.collection("users").document(uid).get()
            .addOnSuccessListener { d ->
                cb(if (d.exists()) User(uid, d.getString("name") ?: "", d.getString("studentNo") ?: "", d.getString("phone") ?: "") else null)
            }
            .addOnFailureListener { cb(null) }
    }

    /** لو في جلسة محفوظة من قبل. */
    fun loadCurrentUser(cb: (User?) -> Unit) {
        val uid = auth.currentUser?.uid
        if (uid == null) cb(null) else loadUser(uid, cb)
    }

    fun changePassword(old: String, new: String, cb: (String?) -> Unit) {
        val u = auth.currentUser
        val em = u?.email
        if (u == null || em == null) { cb("سجّل دخولك الأول"); return }
        u.reauthenticate(EmailAuthProvider.getCredential(em, old))
            .addOnSuccessListener {
                u.updatePassword(new).addOnSuccessListener { cb(null) }.addOnFailureListener { cb(errMsg(it)) }
            }
            .addOnFailureListener { cb("كلمة السر القديمة ما صاح") }
    }

    fun signOut() { auth.signOut(); clearBio(); Session.user = null }

    // ---------- البصمة (محلية على الجهاز) ----------
    fun bioUid(): String? = prefs.getString("bio_uid", null)
    fun setBio(uid: String) { prefs.edit().putString("bio_uid", uid).apply() }
    fun clearBio() { prefs.edit().remove("bio_uid").apply() }

    // ---------- البلاغات ----------
    fun listenPosts(cb: (List<Post>) -> Unit): ListenerRegistration =
        db.collection("posts").orderBy("createdAt", Query.Direction.DESCENDING).limit(100)
            .addSnapshotListener { snap, _ ->
                if (snap != null) cb(snap.documents.mapNotNull { Post.from(it) })
            }

    fun listenPost(id: String, cb: (Post?) -> Unit): ListenerRegistration =
        db.collection("posts").document(id).addSnapshotListener { d, _ ->
            if (d != null) cb(if (d.exists()) Post.from(d) else null)
        }

    fun addPost(p: Post, onFail: (String) -> Unit) {
        db.collection("posts").add(p.toMap()).addOnFailureListener { onFail("ما اتنشر البلاغ: ${it.message}") }
    }

    fun deletePost(id: String) { db.collection("posts").document(id).delete() }

    fun confirmReceipt(postId: String, me: User, cb: (Boolean) -> Unit) {
        val ref = db.collection("posts").document(postId)
        db.runTransaction { tr ->
            val s = tr.get(ref)
            if (s.getString("status") != ST_OPEN) throw IllegalStateException("done")
            tr.update(ref, mapOf(
                "status" to ST_DONE, "receivedBy" to me.name,
                "receivedById" to me.id, "receivedAt" to System.currentTimeMillis()
            ))
            null
        }.addOnSuccessListener { cb(true) }.addOnFailureListener { cb(false) }
    }
}
