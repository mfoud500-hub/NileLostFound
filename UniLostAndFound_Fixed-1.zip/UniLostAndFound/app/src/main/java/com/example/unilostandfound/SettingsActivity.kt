package com.example.unilostandfound

import android.os.Bundle
import android.text.InputType
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.widget.Toolbar
import com.google.android.material.switchmaterial.SwitchMaterial

class SettingsActivity : BaseActivity() {
    private lateinit var me: User
    private var updating = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val u = Session.user
        if (u == null) { finish(); return }
        me = u
        setContentView(R.layout.activity_settings)
        findViewById<Toolbar>(R.id.toolbar).setNavigationOnClickListener { finish() }

        findViewById<TextView>(R.id.tvAvatar).text = me.name.trim().take(1).ifEmpty { "؟" }
        findViewById<TextView>(R.id.tvName).text = me.name
        findViewById<TextView>(R.id.tvStudent).text = "الرقم الجامعي: ${me.studentNo}"
        findViewById<TextView>(R.id.tvPhone).text = me.phone

        val sw = findViewById<SwitchMaterial>(R.id.swBio)
        sw.isChecked = Repo.bioUid() == me.id
        sw.setOnCheckedChangeListener { _, checked ->
            if (updating) return@setOnCheckedChangeListener
            if (checked) {
                if (!biometricAvailable()) {
                    toast("البصمة ما متاحة في جوالك. تأكد إنك سجّلت بصمة في إعدادات الجوال.")
                    setSwitch(sw, false); return@setOnCheckedChangeListener
                }
                promptBiometric("فعّل البصمة", "حُط صباعك للتأكيد", onFail = { setSwitch(sw, false) }) {
                    Repo.setBio(me.id); toast("اتفعّلت البصمة ✅")
                }
            } else {
                if (Repo.bioUid() == me.id) Repo.clearBio()
            }
        }

        findViewById<TextView>(R.id.rowChangePw).setOnClickListener { changePasswordDialog() }
        findViewById<TextView>(R.id.rowAbout).setOnClickListener { showAbout(this) }
        findViewById<TextView>(R.id.rowLogout).setOnClickListener { confirmLogout(this) }
    }

    private fun setSwitch(sw: SwitchMaterial, v: Boolean) { updating = true; sw.isChecked = v; updating = false }

    private fun changePasswordDialog() {
        fun field(h: String) = EditText(this).apply {
            hint = h
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        val old = field("كلمة السر القديمة")
        val new = field("كلمة السر الجديدة (6 على الأقل)")
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(56, 24, 56, 8)
            addView(old); addView(new)
        }
        AlertDialog.Builder(this)
            .setTitle("غيّر كلمة السر 🔑")
            .setView(box)
            .setNegativeButton("إلغاء", null)
            .setPositiveButton("غيّر", null)
            .create().also { d ->
                d.setOnShowListener {
                    d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                        val n = new.text.toString()
                        if (n.length < 6) { toast("كلمة السر الجديدة قصيرة"); return@setOnClickListener }
                        Repo.changePassword(old.text.toString(), n) { err ->
                            if (err == null) { toast("اتغيّرت كلمة السر ✅"); d.dismiss() } else toast(err)
                        }
                    }
                }
            }.show()
    }
}
