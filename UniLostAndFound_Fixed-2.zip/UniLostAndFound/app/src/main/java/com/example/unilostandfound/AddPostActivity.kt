package com.example.unilostandfound

import android.content.ActivityNotFoundException
import android.os.Bundle
import android.os.Environment
import android.widget.ArrayAdapter
import android.widget.AutoCompleteTextView
import android.widget.ImageView
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.widget.Toolbar
import androidx.core.content.FileProvider
import com.google.android.material.button.MaterialButtonToggleGroup
import com.google.android.material.textfield.TextInputEditText
import java.io.File
import java.io.FileOutputStream

class AddPostActivity : BaseActivity() {
    private var pendingFile: File? = null
    private var photoPath: String? = null
    private var saved = false

    private lateinit var ivPhoto: ImageView
    private lateinit var tvHint: TextView
    private lateinit var btnRemove: TextView

    private val takePicture = registerForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        val f = pendingFile
        if (ok && f != null) processPhoto(f) else { f?.delete(); pendingFile = null }
    }

    private val pickImage = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            val f = newImageFile()
            Thread {
                try {
                    contentResolver.openInputStream(uri)?.use { i -> FileOutputStream(f).use { o -> i.copyTo(o) } }
                    val ok = normalizeImage(f.absolutePath)
                    runOnUiThread { onPhotoReady(f, ok) }
                } catch (e: Exception) {
                    runOnUiThread { onPhotoReady(f, false) }
                }
            }.start()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val user = Session.user
        if (user == null) { finish(); return }
        setContentView(R.layout.activity_add_post)
        findViewById<Toolbar>(R.id.toolbar).setNavigationOnClickListener { finish() }

        ivPhoto = findViewById(R.id.ivPhoto)
        tvHint = findViewById(R.id.tvPhotoHint)
        btnRemove = findViewById(R.id.btnRemovePhoto)

        val etTitle = findViewById<TextInputEditText>(R.id.etTitle)
        val etLocation = findViewById<TextInputEditText>(R.id.etLocation)
        val etDesc = findViewById<TextInputEditText>(R.id.etDesc)
        val etPhone = findViewById<TextInputEditText>(R.id.etPhone)
        val etCategory = findViewById<AutoCompleteTextView>(R.id.etCategory)
        val toggle = findViewById<MaterialButtonToggleGroup>(R.id.toggleType)

        val cats = listOf("بطاقة جامعية", "مفاتيح", "موبايل", "شاحن / إلكترونيات", "حقيبة", "كتب ومذكرات",
            "محفظة / فلوس", "نضارة / ساعة", "ملابس", "أخرى")
        etCategory.setAdapter(ArrayAdapter(this, android.R.layout.simple_list_item_1, cats))
        etCategory.setText(cats.last(), false)
        etPhone.setText(user.phone)

        if (savedInstanceState != null) {
            savedInstanceState.getString("pending")?.let { pendingFile = File(it) }
            savedInstanceState.getString("photo")?.let { if (File(it).exists()) { photoPath = it; showPhoto() } }
        }

        findViewById<android.view.View>(R.id.btnCamera).setOnClickListener { launchCamera() }
        findViewById<android.view.View>(R.id.btnGallery).setOnClickListener {
            try { pickImage.launch("image/*") } catch (e: ActivityNotFoundException) { toast("ما لقينا معرض صور") }
        }
        btnRemove.setOnClickListener { removePhoto() }

        findViewById<android.view.View>(R.id.btnPublish).setOnClickListener {
            val title = etTitle.text.toString().trim()
            val loc = etLocation.text.toString().trim()
            val phone = etPhone.text.toString().trim()
            when {
                title.isBlank() -> { toast("اكتب اسم الغرض"); return@setOnClickListener }
                loc.isBlank() -> { toast("اكتب المكان"); return@setOnClickListener }
                phone.filter { it.isDigit() }.length < 9 -> {
                    toast("اكتب رقم التواصل عشان صاحب الغرض يلقاك"); return@setOnClickListener
                }
            }
            val type = if (toggle.checkedButtonId == R.id.btnTypeFound) TYPE_FOUND else TYPE_LOST
            var b64 = ""
            photoPath?.let { path ->
                try {
                    b64 = android.util.Base64.encodeToString(File(path).readBytes(), android.util.Base64.NO_WRAP)
                } catch (e: Exception) { toast("ما قدرنا نقرا الصورة"); return@setOnClickListener }
                if (b64.length > 800_000) { toast("الصورة كبيرة شديد، صوّر تاني"); return@setOnClickListener }
            }
            val app = applicationContext
            Repo.addPost(Post(
                "", user.id, user.name, phone, type, title,
                etCategory.text.toString().ifBlank { "أخرى" }, loc, System.currentTimeMillis(),
                etDesc.text.toString().trim(), b64
            )) { msg -> app.toast(msg) }
            saved = false   // الصورة المحلية بتتمسح لأنها اترفعت جوّه البلاغ
            toast("اتنشر البلاغ ✅")
            finish()
        }
    }

    private fun newImageFile(): File {
        val dir = getExternalFilesDir(Environment.DIRECTORY_PICTURES) ?: File(filesDir, "Pictures")
        dir.mkdirs()
        return File(dir, "IMG_${System.currentTimeMillis()}.jpg")
    }

    private fun launchCamera() {
        val f = newImageFile()
        pendingFile = f
        try {
            val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", f)
            takePicture.launch(uri)
        } catch (e: ActivityNotFoundException) {
            toast("ما لقينا تطبيق كاميرا في الجوال")
        } catch (e: Exception) {
            toast("الكاميرا ما اشتغلت: ${e.message}")
        }
    }

    private fun processPhoto(f: File) {
        Thread {
            val ok = normalizeImage(f.absolutePath)
            runOnUiThread { onPhotoReady(f, ok) }
        }.start()
    }

    private fun onPhotoReady(f: File, ok: Boolean) {
        if (isDestroyed) return
        if (ok) {
            photoPath?.let { if (it != f.absolutePath) File(it).delete() }
            photoPath = f.absolutePath
            showPhoto()
        } else {
            f.delete()
            toast("ما قدرنا نفتح الصورة، جرّب تاني")
        }
        pendingFile = null
    }

    private fun showPhoto() {
        val p = photoPath ?: return
        ivPhoto.setImageBitmap(decodeScaled(p, 1000))
        ivPhoto.show(true); tvHint.show(false); btnRemove.show(true)
    }

    private fun removePhoto() {
        photoPath?.let { File(it).delete() }
        photoPath = null
        ivPhoto.setImageDrawable(null)
        ivPhoto.show(false); tvHint.show(true); btnRemove.show(false)
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        pendingFile?.let { outState.putString("pending", it.absolutePath) }
        photoPath?.let { outState.putString("photo", it) }
    }

    override fun onDestroy() {
        if (!saved && isFinishing) {
            photoPath?.let { File(it).delete() }
            pendingFile?.delete()
        }
        super.onDestroy()
    }
}
