package com.example.unilostandfound

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.appcompat.widget.Toolbar
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.firestore.ListenerRegistration

class ChatsActivity : BaseActivity() {
    private lateinit var me: User
    private lateinit var adapter: ChatAdapter
    private lateinit var tvEmpty: TextView
    private var reg: ListenerRegistration? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val u = Session.user
        if (u == null) { finish(); return }
        me = u
        setContentView(R.layout.activity_chats)
        findViewById<Toolbar>(R.id.toolbar).setNavigationOnClickListener { finish() }
        tvEmpty = findViewById(R.id.tvEmpty)
        adapter = ChatAdapter(me.id) { c ->
            startActivity(Intent(this, ChatActivity::class.java)
                .putExtra("chatId", c.id)
                .putExtra("name", c.otherName(me.id))
                .putExtra("post", c.postTitle))
        }
        findViewById<RecyclerView>(R.id.rvChats).apply {
            layoutManager = LinearLayoutManager(this@ChatsActivity)
            adapter = this@ChatsActivity.adapter
        }
    }

    override fun onStart() {
        super.onStart()
        if (!::adapter.isInitialized) return
        reg = Repo.listenChats(me.id) { list ->
            adapter.submit(list)
            tvEmpty.show(list.isEmpty())
        }
    }

    override fun onStop() {
        reg?.remove(); reg = null
        super.onStop()
    }
}

class ChatAdapter(private val myId: String, private val onClick: (Chat) -> Unit) :
    RecyclerView.Adapter<ChatAdapter.VH>() {
    private var items: List<Chat> = emptyList()
    fun submit(l: List<Chat>) { items = l; notifyDataSetChanged() }

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val card: View = v.findViewById(R.id.card)
        val avatar: TextView = v.findViewById(R.id.tvAvatar)
        val name: TextView = v.findViewById(R.id.tvName)
        val post: TextView = v.findViewById(R.id.tvPost)
        val last: TextView = v.findViewById(R.id.tvLast)
        val time: TextView = v.findViewById(R.id.tvTime)
    }

    override fun onCreateViewHolder(p: ViewGroup, t: Int) =
        VH(LayoutInflater.from(p.context).inflate(R.layout.item_chat, p, false))

    override fun getItemCount() = items.size

    override fun onBindViewHolder(h: VH, i: Int) {
        val c = items[i]
        val n = c.otherName(myId)
        h.avatar.text = n.trim().take(1).ifEmpty { "؟" }
        h.name.text = n
        h.post.text = "بخصوص: ${c.postTitle}"
        h.last.text = (if (c.lastSender == myId) "إنت: " else "") + c.lastMessage
        h.time.text = timeAgo(c.lastAt)
        h.card.setOnClickListener { onClick(c) }
    }
}
