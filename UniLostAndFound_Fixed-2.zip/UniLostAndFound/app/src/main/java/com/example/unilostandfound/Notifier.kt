package com.example.unilostandfound

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.work.Constraints
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.Worker
import androidx.work.WorkerParameters
import com.google.android.gms.tasks.Tasks
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import java.util.concurrent.TimeUnit

/** إشعارات البلاغات الجديدة: بنفحص Firebase كل ~15 دقيقة في الخلفية. */
object Notifier {
    const val CHANNEL = "posts"
    private const val WORK = "poll_posts"

    private fun prefs(c: Context): SharedPreferences =
        c.getSharedPreferences("unilf_local", Context.MODE_PRIVATE)

    fun enabled(c: Context) = prefs(c).getBoolean("notif_on", true)

    fun setEnabled(c: Context, on: Boolean) {
        prefs(c).edit().putBoolean("notif_on", on).apply()
        if (on) {
            prefs(c).edit().putLong("notif_last", System.currentTimeMillis()).apply()
            schedule(c)
        } else cancel(c)
    }

    fun createChannel(c: Context) {
        if (Build.VERSION.SDK_INT >= 26) {
            val ch = NotificationChannel(CHANNEL, "بلاغات المفقودات", NotificationManager.IMPORTANCE_HIGH)
            ch.description = "تنبيه لما حد يلقى أو يضيّع حاجة"
            c.getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
        }
    }

    fun schedule(c: Context) {
        if (!enabled(c)) return
        val p = prefs(c)
        if (!p.contains("notif_last")) p.edit().putLong("notif_last", System.currentTimeMillis()).apply()
        val req = PeriodicWorkRequestBuilder<PostWorker>(15, TimeUnit.MINUTES)
            .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
            .build()
        WorkManager.getInstance(c).enqueueUniquePeriodicWork(WORK, ExistingPeriodicWorkPolicy.KEEP, req)
    }

    fun cancel(c: Context) {
        WorkManager.getInstance(c).cancelUniqueWork(WORK)
        prefs(c).edit().remove("notif_last").apply()
    }

    fun lastSeen(c: Context) = prefs(c).getLong("notif_last", System.currentTimeMillis())
    fun setLastSeen(c: Context, v: Long) { prefs(c).edit().putLong("notif_last", v).apply() }
}

class PostWorker(ctx: Context, params: WorkerParameters) : Worker(ctx, params) {
    override fun doWork(): Result {
        val c = applicationContext
        if (!Notifier.enabled(c)) return Result.success()
        val uid = FirebaseAuth.getInstance().currentUser?.uid ?: return Result.success()
        val last = Notifier.lastSeen(c)
        return try {
            val db = FirebaseFirestore.getInstance()
            val snap = Tasks.await(
                db.collection("posts").whereGreaterThan("createdAt", last).orderBy("createdAt").limit(20).get(),
                30, TimeUnit.SECONDS
            )
            val posts = snap.documents.mapNotNull { Post.from(it) }
            val fresh = posts.filter { it.authorId != uid && it.status == ST_OPEN }

            val chatSnap = Tasks.await(
                db.collection("chats").whereArrayContains("participants", uid).limit(50).get(),
                30, TimeUnit.SECONDS
            )
            val chats = chatSnap.documents.mapNotNull { Chat.from(it) }
            val newMsgs = chats.filter { it.lastAt > last && it.lastSender.isNotEmpty() && it.lastSender != uid }

            val newest = maxOf(
                last,
                posts.maxOfOrNull { it.createdAt } ?: last,
                chats.maxOfOrNull { it.lastAt } ?: last
            )

            val canNotify = Build.VERSION.SDK_INT < 33 ||
                c.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
            if (canNotify && (fresh.isNotEmpty() || newMsgs.isNotEmpty())) {
                Notifier.createChannel(c)
                val open = PendingIntent.getActivity(
                    c, 0, Intent(c, LoginActivity::class.java),
                    PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
                )
                fun show(id: Int, title: String, text: String) {
                    val n = NotificationCompat.Builder(c, Notifier.CHANNEL)
                        .setSmallIcon(R.drawable.ic_notif)
                        .setContentTitle(title)
                        .setContentText(text)
                        .setStyle(NotificationCompat.BigTextStyle().bigText(text))
                        .setPriority(NotificationCompat.PRIORITY_HIGH)
                        .setAutoCancel(true)
                        .setContentIntent(open)
                        .build()
                    NotificationManagerCompat.from(c).notify(id, n)
                }
                fresh.takeLast(5).forEach { p ->
                    val title = if (p.type == TYPE_FOUND) "📦 في زول لقى حاجة" else "🔎 في زول ضاعت منو حاجة"
                    show((p.createdAt % Int.MAX_VALUE).toInt(), title, "${p.title} — ${p.location}\nبلّغ: ${p.authorName}")
                }
                newMsgs.take(5).forEach { ch ->
                    show(ch.id.hashCode(), "💬 رسالة جديدة من ${ch.otherName(uid)}", "${ch.postTitle}: ${ch.lastMessage}")
                }
            }
            Notifier.setLastSeen(c, newest)
            Result.success()
        } catch (e: Exception) {
            Result.retry()
        }
    }
}
