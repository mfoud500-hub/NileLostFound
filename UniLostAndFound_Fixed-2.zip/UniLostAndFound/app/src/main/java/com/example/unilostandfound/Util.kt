package com.example.unilostandfound

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.os.Handler
import android.os.Looper
import android.util.LruCache
import android.view.View
import android.widget.ImageView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.exifinterface.media.ExifInterface
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors

fun Context.toast(msg: CharSequence) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()

fun typeLabel(t: String) = if (t == TYPE_LOST) "ضاع مني 🔎" else "اتلقى 📦"

fun timeAgo(ts: Long): String {
    val min = (System.currentTimeMillis() - ts) / 60000
    return when {
        min < 1 -> "هسّي"
        min < 60 -> when (min) { 1L -> "من دقيقة"; 2L -> "من دقيقتين"; in 3L..10L -> "من $min دقايق"; else -> "من $min دقيقة" }
        min < 60 * 24 -> { val h = min / 60; when (h) { 1L -> "من ساعة"; 2L -> "من ساعتين"; in 3L..10L -> "من $h ساعات"; else -> "من $h ساعة" } }
        else -> { val d = min / (60 * 24); when (d) { 1L -> "من يوم"; 2L -> "من يومين"; in 3L..10L -> "من $d أيام"; else -> "من $d يوم" } }
    }
}

fun shortTime(ts: Long): String = SimpleDateFormat("h:mm a  d/M", Locale.ENGLISH).format(Date(ts))

fun fullDate(ts: Long): String = SimpleDateFormat("d/M/yyyy  h:mm a", Locale.ENGLISH).format(Date(ts))

/** رقم واتساب بصيغة دولية (السودان 249). */
fun waNumber(p: String): String {
    var d = p.filter { it.isDigit() }
    if (d.startsWith("00")) d = d.drop(2)
    if (d.startsWith("0")) d = "249" + d.drop(1)
    else if (d.length == 9) d = "249$d"
    return d
}

// ---------- البصمة ----------
fun Context.biometricAvailable(): Boolean =
    BiometricManager.from(this).canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_WEAK) ==
        BiometricManager.BIOMETRIC_SUCCESS

fun AppCompatActivity.promptBiometric(
    title: String, subtitle: String,
    onFail: () -> Unit = {}, onOk: () -> Unit
) {
    val callback = object : BiometricPrompt.AuthenticationCallback() {
        override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) { onOk() }
        override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
            if (errorCode != BiometricPrompt.ERROR_USER_CANCELED &&
                errorCode != BiometricPrompt.ERROR_NEGATIVE_BUTTON &&
                errorCode != BiometricPrompt.ERROR_CANCELED
            ) toast(errString)
            onFail()
        }
    }
    val info = BiometricPrompt.PromptInfo.Builder()
        .setTitle(title)
        .setSubtitle(subtitle)
        .setNegativeButtonText("استخدم كلمة السر")
        .setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_WEAK)
        .build()
    BiometricPrompt(this, ContextCompat.getMainExecutor(this), callback).authenticate(info)
}

// ---------- الصور ----------
fun decodeScaled(path: String, maxSide: Int): Bitmap? {
    val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    BitmapFactory.decodeFile(path, o)
    if (o.outWidth <= 0 || o.outHeight <= 0) return null
    var s = 1
    while (o.outWidth / (s * 2) >= maxSide || o.outHeight / (s * 2) >= maxSide) s *= 2
    var bmp = BitmapFactory.decodeFile(path, BitmapFactory.Options().apply { inSampleSize = s }) ?: return null
    val rot = try {
        when (ExifInterface(path).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)) {
            ExifInterface.ORIENTATION_ROTATE_90 -> 90f
            ExifInterface.ORIENTATION_ROTATE_180 -> 180f
            ExifInterface.ORIENTATION_ROTATE_270 -> 270f
            else -> 0f
        }
    } catch (e: Exception) { 0f }
    if (rot != 0f) {
        val r = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, Matrix().apply { postRotate(rot) }, true)
        if (r !== bmp) bmp.recycle(); bmp = r
    }
    val big = maxOf(bmp.width, bmp.height)
    if (big > maxSide) {
        val f = maxSide.toFloat() / big
        val r = Bitmap.createScaledBitmap(bmp, (bmp.width * f).toInt(), (bmp.height * f).toInt(), true)
        if (r !== bmp) bmp.recycle(); bmp = r
    }
    return bmp
}

/** يصغّر الصورة ويعدّل اتجاهها ويحفظها فوق نفس الملف. */
fun normalizeImage(path: String): Boolean {
    val b = decodeScaled(path, 800) ?: return false
    FileOutputStream(path).use { b.compress(Bitmap.CompressFormat.JPEG, 70, it) }
    b.recycle()
    return true
}

object ImageLoader {
    private val pool = Executors.newFixedThreadPool(2)
    private val main = Handler(Looper.getMainLooper())
    private val cache = object : LruCache<String, Bitmap>((Runtime.getRuntime().maxMemory() / 1024 / 8).toInt()) {
        override fun sizeOf(key: String, value: Bitmap) = value.byteCount / 1024
    }

    /** الصورة مخزنة نص Base64 داخل البلاغ. */
    fun loadB64(view: ImageView, key: String, b64: String) {
        val k = "b64:$key"
        view.tag = k
        cache.get(k)?.let { view.setImageBitmap(it); return }
        view.setImageDrawable(null)
        pool.execute {
            val bmp = try {
                val bytes = android.util.Base64.decode(b64, android.util.Base64.DEFAULT)
                BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
            } catch (e: Exception) { null }
            if (bmp != null) cache.put(k, bmp)
            main.post { if (view.tag == k && bmp != null) view.setImageBitmap(bmp) }
        }
    }

    fun load(view: ImageView, path: String, maxSide: Int = 900) {
        view.tag = path
        cache.get(path)?.let { view.setImageBitmap(it); return }
        view.setImageDrawable(null)
        pool.execute {
            val bmp = decodeScaled(path, maxSide)
            if (bmp != null) cache.put(path, bmp)
            main.post { if (view.tag == path && bmp != null) view.setImageBitmap(bmp) }
        }
    }
}

fun View.show(v: Boolean) { visibility = if (v) View.VISIBLE else View.GONE }
