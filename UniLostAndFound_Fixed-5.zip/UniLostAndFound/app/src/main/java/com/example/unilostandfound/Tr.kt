package com.example.unilostandfound

import android.content.Context
import android.view.Menu
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.appcompat.app.AppCompatDelegate
import androidx.appcompat.widget.Toolbar
import com.google.android.material.textfield.TextInputLayout

/** اللغة (عربي/English) والمظهر (فاتح/غامق/تلقائي). */
object Tr {
    @Volatile var en = false

    private fun prefs(c: Context) = c.getSharedPreferences("unilf_local", Context.MODE_PRIVATE)

    fun init(c: Context) { en = prefs(c).getString("lang", "ar") == "en" }
    fun setLang(c: Context, lang: String) { prefs(c).edit().putString("lang", lang).apply(); en = lang == "en" }

    /** auto | light | dark */
    fun theme(c: Context): String = prefs(c).getString("theme", "auto") ?: "auto"
    fun setTheme(c: Context, t: String) { prefs(c).edit().putString("theme", t).apply(); applyTheme(c) }
    fun applyTheme(c: Context) {
        AppCompatDelegate.setDefaultNightMode(
            when (theme(c)) {
                "light" -> AppCompatDelegate.MODE_NIGHT_NO
                "dark" -> AppCompatDelegate.MODE_NIGHT_YES
                else -> AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM
            }
        )
    }

    fun tr(s: String): String = if (en) (MAP[s] ?: s) else s

    /** يترجم كل النصوص في الشاشة لو اللغة إنجليزي. */
    fun apply(v: View) {
        if (!en) return
        if (v is TextInputLayout) v.hint?.toString()?.let { val t = tr(it); if (t != it) v.hint = t }
        if (v is Toolbar) {
            v.title?.toString()?.let { val t = tr(it); if (t != it) v.title = t }
            v.subtitle?.toString()?.let { val t = tr(it); if (t != it) v.subtitle = t }
        }
        if (v is TextView) {
            v.text?.toString()?.let { val t = tr(it); if (t != it) v.text = t }
            v.hint?.toString()?.let { val t = tr(it); if (t != it) v.hint = t }
        }
        v.contentDescription?.toString()?.let { val t = tr(it); if (t != it) v.contentDescription = t }
        if (v is ViewGroup) for (i in 0 until v.childCount) apply(v.getChildAt(i))
    }

    fun translateMenu(m: Menu) {
        for (i in 0 until m.size()) {
            val mi = m.getItem(i)
            mi.title = tr(mi.title.toString())
            mi.subMenu?.let { sub -> translateMenu(sub) }
        }
    }

    private val MAP: Map<String, String> = mapOf(
        "بلاغ جديد" to "New report",
        "ضاع مني حاجة" to "I lost something",
        "لقيت حاجة" to "I found something",
        "📷\nصوّر الغرض عشان الناس تعرفو أسرع" to "📷\nTake a photo so people can recognize it faster",
        "صورة الغرض" to "Item photo",
        "📷  صوّر" to "📷  Take photo",
        "🖼️  من المعرض" to "🖼️  From gallery",
        "❌ شيل الصورة" to "❌ Remove photo",
        "اسم الغرض (مطلوب)" to "Item name (required)",
        "النوع" to "Category",
        "وين ضاع / وين لقيتو؟ (مطلوب)" to "Where was it lost / found? (required)",
        "وصف وعلامة مميزة (لون، ماركة...)" to "Description & distinguishing mark (color, brand...)",
        "رقمك للاتصال والواتساب (ما بيظهر للناس)" to "Your number for calls & WhatsApp (hidden from others)",
        "انشر البلاغ" to "Publish report",
        "اكتب رسالتك..." to "Type your message...",
        "إرسال" to "Send",
        "الرسائل" to "Messages",
        "ما عندك رسائل لسّه 💬\nاضغط «دردش مع الناشر» في أي بلاغ" to "No messages yet 💬\nTap “Chat with poster” on any report",
        "شعار جامعة النيل" to "Nile University logo",
        "مفقودات جامعة النيل" to "Nile University Lost & Found",
        "ضاع ليك شي؟ أو لقيت شي؟ نحنا هنا" to "Lost something? Found something? We are here",
        "سجّل دخولك" to "Sign in",
        "اسمك الكامل" to "Full name",
        "الرقم الجامعي" to "Student ID",
        "رقم الموبايل (واتساب)" to "Mobile number (WhatsApp)",
        "كلمة السر" to "Password",
        "أكّد كلمة السر" to "Confirm password",
        "دخول" to "Sign in",
        "👆  ادخل بالبصمة" to "👆  Sign in with fingerprint",
        "ما عندك حساب؟ سجّل هنا" to "No account? Sign up here",
        "جامعة النيل • خلّينا نرجّع الحاجات لأصحابها" to "Nile University • Let us return things to their owners",
        "🔍  دوّر بالاسم أو المكان..." to "🔍  Search by name or place...",
        "الكل" to "All",
        "ضاع منهم" to "Lost",
        "اتلقى" to "Found",
        "اتسلّم" to "Returned",
        "ما في بلاغات هنا هسّي 🤷" to "No reports here right now 🤷",
        "＋  بلّغ عن غرض" to "＋  Report an item",
        "تفاصيل البلاغ" to "Report details",
        "الناشر" to "Poster",
        "📞  اتصل" to "📞  Call",
        "💬  واتساب" to "💬  WhatsApp",
        "💬  دردش مع الناشر" to "💬  Chat with poster",
        "✅  تأكيد الاستلام" to "✅  Confirm receipt",
        "الإعدادات" to "Settings",
        "الأمان" to "Security",
        "👆  الدخول بالبصمة" to "👆  Fingerprint sign-in",
        "🔑  غيّر كلمة السر" to "🔑  Change password",
        "الإشعارات" to "Notifications",
        "🔔  نبّهني لما حد يلقى أو يضيّع حاجة" to "🔔  Notify me when someone finds or loses something",
        "⚡  إشعارات فورية (إشعار صغير دايم)" to "⚡  Instant alerts (small persistent notification)",
        "عامّ" to "General",
        "ℹ️  عن التطبيق" to "ℹ️  About the app",
        "🚪  تسجيل خروج" to "🚪  Log out",
        "شوف التفاصيل وتواصل" to "View details & contact",
        "🗑️  امسح البلاغ" to "🗑️  Delete report",
        "💬  الرسائل" to "💬  Messages",
        "⚙️  الإعدادات" to "⚙️  Settings",
        "بطاقة جامعية" to "University ID card",
        "مفاتيح" to "Keys",
        "موبايل" to "Mobile phone",
        "شاحن / إلكترونيات" to "Charger / Electronics",
        "حقيبة" to "Bag",
        "كتب ومذكرات" to "Books & notes",
        "محفظة / فلوس" to "Wallet / Money",
        "نضارة / ساعة" to "Glasses / Watch",
        "ملابس" to "Clothes",
        "أخرى" to "Other",
        "ما لقينا معرض صور" to "No gallery app found",
        "اكتب اسم الغرض" to "Enter the item name",
        "اكتب المكان" to "Enter the place",
        "اكتب رقم التواصل عشان صاحب الغرض يلقاك" to "Enter a contact number so the owner can reach you",
        "ما قدرنا نقرا الصورة" to "Could not read the photo",
        "الصورة كبيرة شديد، صوّر تاني" to "The photo is too large, take another one",
        "اتنشر البلاغ ✅" to "Report published ✅",
        "ما لقينا تطبيق كاميرا في الجوال" to "No camera app found on this phone",
        "الكاميرا ما اشتغلت: " to "Camera failed: ",
        "ما قدرنا نفتح الصورة، جرّب تاني" to "Could not open the photo, try again",
        "محادثة" to "Chat",
        "بخصوص: " to "About: ",
        "إنت: " to "You: ",
        "سوّي حساب جديد" to "Create a new account",
        "سجّل" to "Sign up",
        "عندك حساب؟ ادخل من هنا" to "Have an account? Sign in here",
        "ادخل بالبصمة" to "Sign in with fingerprint",
        "حُط صباعك على الحساس" to "Place your finger on the sensor",
        "استنى شوية..." to "Please wait...",
        "اكتب الرقم الجامعي صاح" to "Enter a valid student ID",
        "اكتب اسمك الكامل" to "Enter your full name",
        "رقم الموبايل ما صاح" to "Invalid mobile number",
        "كلمة السر لازم تكون 6 حروف أو أرقام على الأقل" to "Password must be at least 6 characters",
        "كلمتين السر ما متطابقات" to "Passwords do not match",
        "حصل خطأ، جرّب تاني" to "Something went wrong, try again",
        "اكتب كلمة السر" to "Enter your password",
        "البصمة 👆" to "Fingerprint 👆",
        "تحب تدخل بالبصمة المرة الجاية؟" to "Sign in with your fingerprint next time?",
        "لا، هسّي" to "Not now",
        "أيوا، فعّلها" to "Yes, enable it",
        "فعّل البصمة" to "Enable fingerprint",
        "حُط صباعك للتأكيد" to "Place your finger to confirm",
        "اتفعّلت البصمة ✅" to "Fingerprint enabled ✅",
        "ما قدرنا نحدّث، اتأكد من النت" to "Could not refresh, check your connection",
        "تمام" to "OK",
        "تسجيل خروج" to "Log out",
        "متأكد عايز تطلع؟ (البصمة بتتعطّل وبتحتاج تفعّلها تاني بعد ما تدخل)" to "Are you sure you want to log out? (Fingerprint will be turned off; enable it again after signing in)",
        "لا" to "No",
        "أيوا، اطلع" to "Yes, log out",
        "أي حاجة ضاعت منك داخل الجامعة، بلّغ عنها هنا. وأي حاجة لقيتها، انشرها عشان توصل لصاحبها.\n\nكل طلاب الجامعة بيشوفوا البلاغات. صاحب الغرض بيتواصل مع الناشر، بيتأكد منو، وبعد الاستلام بيضغط «تأكيد الاستلام»." to "Anything you lost on campus, report it here. Anything you found, post it so it reaches its owner.\n\nAll university students can see the reports. The owner contacts the poster, verifies the item, and taps “Confirm receipt” after getting it back.",
        "بلاغات المفقودات" to "Lost & found reports",
        "تنبيه لما حد يلقى أو يضيّع حاجة" to "Alerts when someone finds or loses something",
        "التنبيهات الفورية" to "Instant alerts",
        "إشعار صغير دايم عشان التنبيهات توصل بسرعة" to "A small persistent notification so alerts arrive quickly",
        "📦 في زول لقى حاجة" to "📦 Someone found something",
        "🔎 في زول ضاعت منو حاجة" to "🔎 Someone lost something",
        "التنبيهات الفورية شغّالة" to "Instant alerts are on",
        "بلّغ: " to "Posted by: ",
        "💬 رسالة جديدة من " to "💬 New message from ",
        "  (إنت)" to "  (you)",
        "التواصل: اتصال • واتساب • شات" to "Contact: call • WhatsApp • chat",
        "ما قدرنا نفتح واتساب" to "Could not open WhatsApp",
        "💬  شوف الرسائل" to "💬  View messages",
        "💬  دردش مع الناشر في التطبيق" to "💬  Chat with the poster in the app",
        "البلاغ دا خلص ✔️" to "This report is closed ✔️",
        "الإعلان دا إنت نشرتو. لمّا غرضك يرجع ليك اضغط «تأكيد الاستلام» تحت." to "You posted this report. When your item is returned to you, tap “Confirm receipt” below.",
        "الإعلان دا إنت نشرتو. لمّا صاحب الغرض يستلمو بيضغط «تأكيد الاستلام» وإنت بتشوف الحالة هنا." to "You posted this report. When the owner receives the item they will tap “Confirm receipt” and you will see the status here.",
        "دا بتاعك؟ كلّم الناشر وصّف ليهو الغرض وعلامة مميزة فيهو (لون، ماركة، شنو جواهو)، وقابلو جوّه الجامعة. بعد ما تستلم اضغط «تأكيد الاستلام»." to "Is this yours? Contact the poster, describe the item and a distinguishing mark (color, brand, what is inside), and meet on campus. After you receive it, tap “Confirm receipt”.",
        "لقيت الغرض؟ كلّم صاحبو واتأكد إنو بيوصّفو صاح قبل ما تسلّمو. بعد التسليم هو بيضغط «تأكيد الاستلام»." to "Found the item? Contact its owner and make sure they describe it correctly before handing it over. After the handover they will tap “Confirm receipt”.",
        "تأكيد الاستلام ✅" to "Confirm receipt ✅",
        "إنت استلمت الغرض فعلاً وتأكدت إنو بتاعك؟ بعد التأكيد البلاغ بيتقفل." to "Did you actually receive the item and make sure it is yours? After confirming, the report will be closed.",
        "لسّه" to "Not yet",
        "أيوا، استلمت" to "Yes, I received it",
        "الحمد لله، اتأكد الاستلام 🎉" to "Receipt confirmed 🎉",
        "ما قدرنا نأكّد، اتأكد من النت وجرّب تاني" to "Could not confirm, check your connection and try again",
        "مسح البلاغ" to "Delete report",
        "عايز تمسح البلاغ دا؟" to "Do you want to delete this report?",
        "امسحو" to "Delete",
        "الرقم الجامعي دا مسجّل من قبل" to "This student ID is already registered",
        "الرقم الجامعي أو كلمة السر ما صاح يا زول" to "Wrong student ID or password",
        "ما في نت، اتأكد من الاتصال" to "No internet, check your connection",
        "محاولات كتيرة، استنى شوية وجرّب" to "Too many attempts, wait a bit and try again",
        "حصل خطأ: " to "Error: ",
        "اتسجّل الحساب لكن ما اتحفظت بياناتك، جرّب تدخل تاني" to "Account created but your data was not saved, try signing in again",
        "ما لقينا بيانات الحساب، جرّب تاني" to "Account data not found, try again",
        "سجّل دخولك الأول" to "Please sign in first",
        "كلمة السر القديمة ما صاح" to "Old password is incorrect",
        "ما اتنشر البلاغ: " to "Could not publish the report: ",
        "ما اترسلت الرسالة: " to "Message not sent: ",
        "الرقم الجامعي: " to "Student ID: ",
        "البصمة ما متاحة في جوالك. تأكد إنك سجّلت بصمة في إعدادات الجوال." to "Fingerprint is not available on your phone. Make sure you enrolled one in phone settings.",
        "كلمة السر القديمة" to "Old password",
        "كلمة السر الجديدة (6 على الأقل)" to "New password (at least 6)",
        "غيّر كلمة السر 🔑" to "Change password 🔑",
        "إلغاء" to "Cancel",
        "غيّر" to "Change",
        "كلمة السر الجديدة قصيرة" to "The new password is too short",
        "اتغيّرت كلمة السر ✅" to "Password changed ✅",
        "استخدم كلمة السر" to "Use password",
        "🏠  الرئيسية" to "🏠  Home",
        "الحساب" to "Account",
        "🔄  تبديل الحساب" to "🔄  Switch account",
        "تبديل الحساب" to "Switch account",
        "هتطلع من الحساب الحالي وتدخل بحساب تاني (مثلاً حساب زميلك). تمام؟" to "You will sign out of this account and sign in with another one (for example a friend's account). Continue?",
        "أيوا، بدّل" to "Yes, switch",
        "المظهر واللغة" to "Appearance & language",
        "🌓  المظهر" to "🌓  Theme",
        "🌐  اللغة" to "🌐  Language",
        "المظهر" to "Theme",
        "اللغة" to "Language",
        "تلقائي (حسب الجوال)" to "Automatic (follow phone)",
        "فاتح" to "Light",
        "غامق" to "Dark",
        "عن التطبيق" to "About",
        "الإصدار" to "Version"
    )
}

fun tr(s: String): String = Tr.tr(s)
