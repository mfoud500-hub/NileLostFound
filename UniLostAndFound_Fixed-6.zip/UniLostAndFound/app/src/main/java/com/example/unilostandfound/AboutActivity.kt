package com.example.unilostandfound

import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.widget.Toolbar

class AboutActivity : BaseActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_about)
        findViewById<Toolbar>(R.id.toolbar).setNavigationOnClickListener { finish() }
        val ver = try { packageManager.getPackageInfo(packageName, 0).versionName } catch (e: Exception) { "" }
        findViewById<TextView>(R.id.tvVersion).text = tr("الإصدار") + " " + ver
        findViewById<TextView>(R.id.tvAbout).text = tr("أي حاجة ضاعت منك داخل الجامعة، بلّغ عنها هنا. وأي حاجة لقيتها، انشرها عشان توصل لصاحبها.\n\nكل طلاب الجامعة بيشوفوا البلاغات. صاحب الغرض بيتواصل مع الناشر، بيتأكد منو، وبعد الاستلام بيضغط «تأكيد الاستلام».")
    }
}
