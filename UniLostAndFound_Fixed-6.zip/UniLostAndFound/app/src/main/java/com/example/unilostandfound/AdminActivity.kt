package com.example.unilostandfound

import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.widget.Toolbar
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.button.MaterialButton
import com.google.android.material.chip.ChipGroup
import com.google.firebase.firestore.ListenerRegistration

/** صف في لوحة الأدمن: إما بلاغ مبلّغ عنو أو مستخدم. */
data class AdminRow(
    val id: String, val title: String, val sub: String, val isReport: Boolean,
    val postId: String = "", val blocked: Boolean = false, val canBlock: Boolean = false,
    val isOffice: Boolean = false
)

class AdminActivity : BaseActivity() {
    private lateinit var adapter: AdminAdapter
    private lateinit var tvEmpty: TextView
    private lateinit var etSearch: EditText
    private var reg: ListenerRegistration? = null
    private var showUsers = false
    private var showOffice = false
    private var rows: List<AdminRow> = emptyList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Session.user?.isAdmin != true) { finish(); return }
        setContentView(R.layout.activity_admin)
        findViewById<Toolbar>(R.id.toolbar).setNavigationOnClickListener { finish() }
        tvEmpty = findViewById(R.id.tvEmpty)
        etSearch = findViewById(R.id.etSearch)

        adapter = AdminAdapter { row, which -> onAction(row, which) }
        findViewById<RecyclerView>(R.id.rvAdmin).apply {
            layoutManager = LinearLayoutManager(this@AdminActivity)
            adapter = this@AdminActivity.adapter
        }
        findViewById<ChipGroup>(R.id.chipGroup).setOnCheckedStateChangeListener { _, ids ->
            showUsers = ids.firstOrNull() == R.id.chipUsers
            showOffice = ids.firstOrNull() == R.id.chipOffice
            etSearch.visibility = if (showUsers) View.VISIBLE else View.GONE
            load()
        }
        etSearch.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) { render() }
            override fun afterTextChanged(s: Editable?) {}
        })
    }

    override fun onStart() {
        super.onStart()
        if (::adapter.isInitialized) load()
    }

    override fun onStop() {
        reg?.remove(); reg = null
        super.onStop()
    }

    private fun load() {
        reg?.remove(); reg = null
        if (showOffice) {
            reg = Repo.listenOfficePosts { list ->
                rows = list.map {
                    AdminRow(it.id, "🏢 " + it.title,
                        (if (it.officeCondition.isNotBlank()) tr(it.officeCondition) + "  •  " else "") +
                            tr("بواسطة: ") + it.officeBy + "  •  " + timeAgo(it.officeAt),
                        false, postId = it.id, isOffice = true)
                }
                render()
            }
        } else if (!showUsers) {
            reg = Repo.listenReports { list ->
                rows = list.map {
                    AdminRow(it.id, "🚩 " + it.postTitle,
                        tr(it.reason) + "  •  " + tr("بواسطة: ") + it.reporterName + "  •  " + timeAgo(it.createdAt),
                        true, postId = it.postId)
                }
                render()
            }
        } else {
            Repo.listUsers { list ->
                if (list == null) { toast("ما قدرنا ننفّذ الطلب، اتأكد من الصلاحيات والنت"); return@listUsers }
                rows = list.map {
                    AdminRow(it.id,
                        it.name + (if (it.isAdmin) " 🛡️" else "") + (if (it.blocked) " ⛔" else ""),
                        tr("الرقم الجامعي: ") + it.studentNo + "  •  " + it.phone,
                        false, blocked = it.blocked, canBlock = !it.isAdmin && it.id != Session.user?.id)
                }
                render()
            }
        }
    }

    private fun render() {
        val q = etSearch.text.toString().trim()
        val list = if (showUsers && q.isNotEmpty()) rows.filter { (it.title + it.sub).contains(q, ignoreCase = true) } else rows
        adapter.submit(list)
        tvEmpty.visibility = if (list.isEmpty()) View.VISIBLE else View.GONE
    }

    private fun onAction(row: AdminRow, which: Int) {
        if (row.isOffice) {
            when (which) {
                1 -> startActivity(Intent(this, PostDetailActivity::class.java).putExtra("id", row.postId))
                2 -> Session.user?.let { handoverDialog(this, row.postId, it) }
            }
        } else if (row.isReport) {
            when (which) {
                1 -> startActivity(Intent(this, PostDetailActivity::class.java).putExtra("id", row.postId))
                2 -> AlertDialog.Builder(this)
                    .setTitle(tr("مسح البلاغ"))
                    .setMessage(tr("عايز تمسح البلاغ المبلّغ عنو نهائياً؟"))
                    .setNegativeButton(tr("لا"), null)
                    .setPositiveButton(tr("امسحو")) { _, _ -> Repo.deletePost(row.postId); Repo.deleteReport(row.id) }
                    .show()
                3 -> Repo.deleteReport(row.id)
            }
        } else if (which == 1 && row.canBlock) {
            val block = !row.blocked
            fun go() = Repo.setBlocked(row.id, block) { ok ->
                if (ok) { toast(if (block) "اتحظر الحساب" else "اتفك الحظر"); load() }
                else toast("ما قدرنا ننفّذ الطلب، اتأكد من الصلاحيات والنت")
            }
            if (block) AlertDialog.Builder(this)
                .setTitle(tr("حظر الحساب"))
                .setMessage(tr("الحساب المحظور ما بيقدر ينشر بلاغات ولا يرسل رسائل. تمام؟"))
                .setNegativeButton(tr("لا"), null)
                .setPositiveButton(tr("حظر")) { _, _ -> go() }.show()
            else go()
        }
    }
}

class AdminAdapter(private val onAction: (AdminRow, Int) -> Unit) : RecyclerView.Adapter<AdminAdapter.VH>() {
    private var items: List<AdminRow> = emptyList()
    fun submit(l: List<AdminRow>) { items = l; notifyDataSetChanged() }

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val title: TextView = v.findViewById(R.id.tvTitle)
        val sub: TextView = v.findViewById(R.id.tvSub)
        val b1: MaterialButton = v.findViewById(R.id.b1)
        val b2: MaterialButton = v.findViewById(R.id.b2)
        val b3: MaterialButton = v.findViewById(R.id.b3)
    }

    override fun onCreateViewHolder(p: ViewGroup, t: Int) =
        VH(LayoutInflater.from(p.context).inflate(R.layout.item_admin, p, false))

    override fun getItemCount() = items.size

    override fun onBindViewHolder(h: VH, i: Int) {
        val r = items[i]
        h.title.text = r.title
        h.sub.text = r.sub
        h.b2.setTextColor(h.itemView.context.getColor(if (r.isOffice) R.color.green else R.color.red))
        if (r.isOffice) {
            h.b1.text = tr("عرض البلاغ"); h.b2.text = tr("✅ تسليم")
            h.b1.visibility = View.VISIBLE; h.b2.visibility = View.VISIBLE; h.b3.visibility = View.GONE
        } else if (r.isReport) {
            h.b1.text = tr("عرض البلاغ"); h.b2.text = tr("مسح البلاغ"); h.b3.text = tr("تجاهل")
            h.b1.visibility = View.VISIBLE; h.b2.visibility = View.VISIBLE; h.b3.visibility = View.VISIBLE
        } else {
            h.b1.text = tr(if (r.blocked) "إلغاء الحظر" else "حظر")
            h.b1.visibility = if (r.canBlock) View.VISIBLE else View.GONE
            h.b2.visibility = View.GONE; h.b3.visibility = View.GONE
        }
        h.b1.setOnClickListener { onAction(r, 1) }
        h.b2.setOnClickListener { onAction(r, 2) }
        h.b3.setOnClickListener { onAction(r, 3) }
    }
}
