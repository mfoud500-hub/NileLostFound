package com.example.unilostandfound

import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity

abstract class BaseActivity : AppCompatActivity() {
    private var langAtCreate = false

    override fun onCreate(savedInstanceState: Bundle?) {
        Repo.init(this)
        Tr.applyTheme(this)
        super.onCreate(savedInstanceState)
        langAtCreate = Tr.en
        window.decorView.layoutDirection = if (Tr.en) View.LAYOUT_DIRECTION_LTR else View.LAYOUT_DIRECTION_RTL
    }

    override fun setContentView(layoutResID: Int) {
        super.setContentView(layoutResID)
        Tr.apply(window.decorView)
    }

    override fun onResume() {
        super.onResume()
        // لو اللغة اتغيّرت من الإعدادات، نعيد رسم الشاشة
        if (Tr.en != langAtCreate) recreate()
    }
}
