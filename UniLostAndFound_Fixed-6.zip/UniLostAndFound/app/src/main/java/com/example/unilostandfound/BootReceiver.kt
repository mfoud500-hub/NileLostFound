package com.example.unilostandfound

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** بعد إعادة تشغيل الجوال بنرجّع التنبيهات الفورية لوحدها. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED) {
            Repo.init(context)
            Notifier.schedule(context)
            Notifier.startLive(context)
        }
    }
}
