package com.example.unilostandfound

import android.os.Bundle
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.widget.Toolbar
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.firestore.ListenerRegistration

class ChatActivity : BaseActivity() {
    private var chatId = ""
    private lateinit var me: User
    private lateinit var rv: RecyclerView
    private val adapter = MsgAdapter { Session.user?.id ?: "" }
    private var reg: ListenerRegistration? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val u = Session.user
        val id = intent.getStringExtra("chatId")
        if (u == null || id == null) { finish(); return }
        me = u; chatId = id
        setContentView(R.layout.activity_chat)

        val tb = findViewById<Toolbar>(R.id.toolbar)
        tb.title = intent.getStringExtra("name") ?: "محادثة"
        tb.subtitle = intent.getStringExtra("post") ?: ""
        tb.setNavigationOnClickListener { finish() }

        rv = findViewById(R.id.rvMsgs)
        rv.layoutManager = LinearLayoutManager(this).apply { stackFromEnd = true }
        rv.adapter = adapter

        val et = findViewById<EditText>(R.id.etMsg)
        findViewById<View>(R.id.btnSend).setOnClickListener {
            val t = et.text.toString().trim()
            if (t.isEmpty()) return@setOnClickListener
            et.setText("")
            val app = applicationContext
            Repo.sendMessage(chatId, me, t) { msg -> app.toast(msg) }
        }
    }

    override fun onStart() {
        super.onStart()
        if (chatId.isEmpty()) return
        Notifier.activeChat = chatId
        reg = Repo.listenMessages(chatId) { list ->
            adapter.submit(list)
            if (list.isNotEmpty()) rv.scrollToPosition(list.size - 1)
        }
    }

    override fun onStop() {
        reg?.remove(); reg = null
        if (Notifier.activeChat == chatId) Notifier.activeChat = null
        super.onStop()
    }
}

class MsgAdapter(private val myId: () -> String) : RecyclerView.Adapter<MsgAdapter.VH>() {
    private var items: List<Msg> = emptyList()
    fun submit(l: List<Msg>) { items = l; notifyDataSetChanged() }

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val text: TextView = v.findViewById(R.id.tvText)
        val time: TextView = v.findViewById(R.id.tvTime)
    }

    override fun onCreateViewHolder(p: ViewGroup, t: Int) =
        VH(LayoutInflater.from(p.context).inflate(R.layout.item_msg, p, false))

    override fun getItemCount() = items.size

    override fun onBindViewHolder(h: VH, i: Int) {
        val m = items[i]
        val mine = m.sender == myId()
        val g = if (mine) Gravity.START else Gravity.END
        h.text.text = m.text
        h.time.text = if (m.at > 0) shortTime(m.at) else ""
        h.text.setBackgroundResource(if (mine) R.drawable.bg_bubble_me else R.drawable.bg_bubble_other)
        h.text.setTextColor(h.itemView.context.getColor(if (mine) R.color.white else R.color.ink))
        (h.text.layoutParams as LinearLayout.LayoutParams).gravity = g
        (h.time.layoutParams as LinearLayout.LayoutParams).gravity = g
        h.text.requestLayout(); h.time.requestLayout()
    }
}
