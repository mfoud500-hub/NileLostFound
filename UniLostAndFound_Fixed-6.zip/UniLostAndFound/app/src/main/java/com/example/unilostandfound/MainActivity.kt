package com.example.unilostandfound

import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.Menu
import android.view.MenuItem
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.widget.Toolbar
import androidx.core.view.GravityCompat
import androidx.drawerlayout.widget.DrawerLayout
import com.google.android.material.navigation.NavigationView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import com.google.android.material.chip.ChipGroup
import com.google.android.material.floatingactionbutton.ExtendedFloatingActionButton
import com.google.firebase.firestore.ListenerRegistration

class MainActivity : BaseActivity() {
    private lateinit var adapter: PostAdapter
    private lateinit var etSearch: EditText
    private lateinit var tvStats: TextView
    private lateinit var tvEmpty: TextView
    private var filter = "all"
    private var allPosts: List<Post> = emptyList()
    private var reg: ListenerRegistration? = null
    private lateinit var drawer: DrawerLayout
    private val notifPerm = registerForActivityResult(androidx.activity.result.contract.ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Session.user == null) {
            startActivity(Intent(this, LoginActivity::class.java)); finish(); return
        }
        setContentView(R.layout.activity_main)
        val tb = findViewById<Toolbar>(R.id.toolbar)
        setSupportActionBar(tb)
        tb.setNavigationIcon(R.drawable.ic_menu)

        // القائمة الجانبية
        drawer = findViewById(R.id.drawer)
        tb.setNavigationOnClickListener { drawer.openDrawer(GravityCompat.START) }
        val nav = findViewById<NavigationView>(R.id.nav)
        nav.menu.findItem(R.id.nav_admin).isVisible = Session.user?.isAdmin == true
        Tr.translateMenu(nav.menu)
        Session.user?.let { u ->
            val h = nav.getHeaderView(0)
            h.findViewById<TextView>(R.id.tvNavName).text = u.name
            h.findViewById<TextView>(R.id.tvNavSub).text =
                if (u.isAdmin) tr("🛡️ شؤون الطلاب (أدمن)") else tr("الرقم الجامعي: ") + u.studentNo
        }
        nav.setNavigationItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_chats -> startActivity(Intent(this, ChatsActivity::class.java))
                R.id.nav_settings -> startActivity(Intent(this, SettingsActivity::class.java))
                R.id.nav_admin -> startActivity(Intent(this, AdminActivity::class.java))
                R.id.nav_about -> startActivity(Intent(this, AboutActivity::class.java))
                R.id.nav_switch -> switchAccount(this)
                R.id.nav_logout -> confirmLogout(this)
            }
            drawer.closeDrawer(GravityCompat.START)
            false
        }
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (drawer.isDrawerOpen(GravityCompat.START)) drawer.closeDrawer(GravityCompat.START)
                else { isEnabled = false; onBackPressedDispatcher.onBackPressed() }
            }
        })

        etSearch = findViewById(R.id.etSearch)
        tvStats = findViewById(R.id.tvStats)
        tvEmpty = findViewById(R.id.tvEmpty)

        adapter = PostAdapter { post ->
            startActivity(Intent(this, PostDetailActivity::class.java).putExtra("id", post.id))
        }
        findViewById<RecyclerView>(R.id.rvPosts).apply {
            layoutManager = LinearLayoutManager(this@MainActivity)
            adapter = this@MainActivity.adapter
        }

        findViewById<ChipGroup>(R.id.chipGroup).setOnCheckedStateChangeListener { _, ids ->
            filter = when (ids.firstOrNull()) {
                R.id.chipLost -> TYPE_LOST
                R.id.chipFound -> TYPE_FOUND
                R.id.chipOffice -> ST_OFFICE
                R.id.chipDone -> ST_DONE
                else -> "all"
            }
            render()
        }
        etSearch.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) { render() }
            override fun afterTextChanged(s: Editable?) {}
        })
        findViewById<ExtendedFloatingActionButton>(R.id.fabAdd).setOnClickListener {
            startActivity(Intent(this, AddPostActivity::class.java))
        }

        // اسحب لتحت عشان تحدّث
        findViewById<SwipeRefreshLayout>(R.id.swipe).apply {
            setColorSchemeResources(R.color.blue_dark)
            setProgressBackgroundColorSchemeResource(R.color.mango)
            setOnRefreshListener {
                Notifier.startLive(this@MainActivity)
                Repo.refreshPosts { list ->
                    isRefreshing = false
                    if (list == null) toast("ما قدرنا نحدّث، اتأكد من النت")
                    else { allPosts = list; render() }
                }
            }
        }

        // الإشعارات
        Notifier.createChannel(this)
        if (android.os.Build.VERSION.SDK_INT >= 33 && Notifier.enabled(this) &&
            checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED
        ) notifPerm.launch(android.Manifest.permission.POST_NOTIFICATIONS)
        Notifier.schedule(this)
        Notifier.startLive(this)
    }

    override fun onStart() {
        super.onStart()
        if (!::adapter.isInitialized) return
        // تحديث مباشر: أي بلاغ جديد من أي طالب بيظهر هنا علطول
        reg = Repo.listenPosts { list -> allPosts = list; render() }
    }

    override fun onStop() {
        reg?.remove(); reg = null
        super.onStop()
    }

    private fun render() {
        val q = etSearch.text.toString().trim()
        val list = allPosts.filter { p ->
            val okFilter = when (filter) {
                "all" -> true
                ST_DONE -> p.status == ST_DONE
                ST_OFFICE -> p.status == ST_OFFICE
                else -> p.type == filter && p.status == ST_OPEN
            }
            val hay = "${p.title} ${p.category} ${p.location} ${p.description} ${p.authorName}"
            okFilter && hay.contains(q, ignoreCase = true)
        }.sortedWith(compareBy<Post> { it.status == ST_DONE }.thenByDescending { it.createdAt })

        adapter.submit(list)
        tvEmpty.show(list.isEmpty())
        val open = allPosts.count { it.status == ST_OPEN }
        val office = allPosts.count { it.status == ST_OFFICE }
        val done = allPosts.size - open - office
        tvStats.text = if (Tr.en) "$open open  •  $office at the office  •  $done returned"
        else "$open بلاغ مفتوح  •  $office في الشؤون  •  $done اتسلّم"
    }
}

fun confirmLogout(a: AppCompatActivity) {
    AlertDialog.Builder(a)
        .setTitle(tr("تسجيل خروج"))
        .setMessage(tr("متأكد عايز تطلع؟ (البصمة بتتعطّل وبتحتاج تفعّلها تاني بعد ما تدخل)"))
        .setNegativeButton(tr("لا"), null)
        .setPositiveButton(tr("أيوا، اطلع")) { _, _ ->
            Repo.signOut()
            a.startActivity(Intent(a, LoginActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK))
        }.show()
}

fun switchAccount(a: AppCompatActivity) {
    AlertDialog.Builder(a)
        .setTitle(tr("تبديل الحساب"))
        .setMessage(tr("هتطلع من الحساب الحالي وتدخل بحساب تاني (مثلاً حساب زميلك). تمام؟"))
        .setNegativeButton(tr("لا"), null)
        .setPositiveButton(tr("أيوا، بدّل")) { _, _ ->
            Repo.signOut()
            a.startActivity(Intent(a, LoginActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK))
        }.show()
}
