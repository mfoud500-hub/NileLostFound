package com.example.unilostandfound

import com.google.firebase.firestore.DocumentSnapshot

const val TYPE_LOST = "lost"
const val TYPE_FOUND = "found"
const val ST_OPEN = "open"
const val ST_DONE = "done"
const val ST_OFFICE = "office"   // الغرض موجود في مكتب شؤون الطلاب

data class User(
    val id: String, val name: String, val studentNo: String, val phone: String,
    val isAdmin: Boolean = false, val blocked: Boolean = false
)

/** المستخدم الحالي في الذاكرة بعد تسجيل الدخول. */
object Session { var user: User? = null }

data class Post(
    val id: String, val authorId: String, val authorName: String, val authorPhone: String,
    val type: String, val title: String, val category: String, val location: String,
    val createdAt: Long, val description: String, val photoB64: String,
    var status: String = ST_OPEN, var receivedBy: String = "", var receivedAt: Long = 0L,
    var officeBy: String = "", var officeAt: Long = 0L, var officeCondition: String = "",
    var officeNote: String = "", var handedBy: String = ""
) {
    fun toMap(): Map<String, Any> = hashMapOf(
        "authorId" to authorId, "authorName" to authorName, "authorPhone" to authorPhone,
        "type" to type, "title" to title, "category" to category, "location" to location,
        "createdAt" to createdAt, "description" to description, "photoB64" to photoB64,
        "status" to status, "receivedBy" to receivedBy, "receivedAt" to receivedAt,
        "officeBy" to officeBy, "officeAt" to officeAt, "officeCondition" to officeCondition,
        "officeNote" to officeNote, "handedBy" to handedBy
    )

    companion object {
        fun from(d: DocumentSnapshot): Post? {
            val title = d.getString("title") ?: return null
            return Post(
                d.id, d.getString("authorId") ?: "", d.getString("authorName") ?: "",
                d.getString("authorPhone") ?: "", d.getString("type") ?: TYPE_LOST, title,
                d.getString("category") ?: "", d.getString("location") ?: "",
                d.getLong("createdAt") ?: 0L, d.getString("description") ?: "",
                d.getString("photoB64") ?: "", d.getString("status") ?: ST_OPEN,
                d.getString("receivedBy") ?: "", d.getLong("receivedAt") ?: 0L,
                d.getString("officeBy") ?: "", d.getLong("officeAt") ?: 0L, d.getString("officeCondition") ?: "",
                d.getString("officeNote") ?: "", d.getString("handedBy") ?: ""
            )
        }
    }
}

data class Chat(
    val id: String, val postId: String, val postTitle: String,
    val userA: String, val nameA: String, val userB: String, val nameB: String,
    val lastMessage: String, val lastAt: Long, val lastSender: String
) {
    fun otherName(me: String) = if (me == userA) nameB else nameA

    companion object {
        fun from(d: DocumentSnapshot): Chat? {
            val a = d.getString("userA") ?: return null
            return Chat(
                d.id, d.getString("postId") ?: "", d.getString("postTitle") ?: "",
                a, d.getString("nameA") ?: "", d.getString("userB") ?: "", d.getString("nameB") ?: "",
                d.getString("lastMessage") ?: "", d.getLong("lastAt") ?: 0L, d.getString("lastSender") ?: ""
            )
        }
    }
}

data class Msg(val id: String, val sender: String, val text: String, val at: Long)

data class Report(
    val id: String, val postId: String, val postTitle: String,
    val reporterName: String, val reason: String, val createdAt: Long
)
