package com.example.unilostandfound

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.work.Constraints
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.Worker
import androidx.work.WorkerParameters
import com.google.android.gms.tasks.Tasks
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.DocumentChange
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import java.util.concurrent.TimeUnit

/**
 * الإشعارات:
 *  1) خدمة فورية (LiveService) بتسمع Firebase طول الوقت، والإشعار بيصل في ثواني.
 *  2) WorkManager كل ~15 دقيقة كاحتياط لو النظام قفل الخدمة.
 */
object Notifier {
    const val CHANNEL = "posts"
    const val CHANNEL_LIVE = "live"
    private const val WORK = "poll_posts"

    /** المحادثة المفتوحة هسّي (ما بنطلّع إشعار ليها). */
    @Volatile var activeChat: String? = null

    private fun prefs(c: Context): SharedPreferences =
        c.getSharedPreferences("unilf_local", Context.MODE_PRIVATE)

    fun enabled(c: Context) = prefs(c).getBoolean("notif_on", true)
    fun liveEnabled(c: Context) = prefs(c).getBoolean("live_on", true)

    fun setEnabled(c: Context, on: Boolean) {
        prefs(c).edit().putBoolean("notif_on", on).apply()
        if (on) {
            prefs(c).edit().putLong("notif_last", System.currentTimeMillis()).apply()
            schedule(c); startLive(c)
        } else { cancel(c); stopLive(c) }
    }

    fun setLive(c: Context, on: Boolean) {
        prefs(c).edit().putBoolean("live_on", on).apply()
        if (on) startLive(c) else stopLive(c)
    }

    fun startLive(c: Context) {
        if (!enabled(c) || !liveEnabled(c)) return
        try { ContextCompat.startForegroundService(c, Intent(c, LiveService::class.java)) } catch (e: Exception) { }
    }

    fun stopLive(c: Context) { c.stopService(Intent(c, LiveService::class.java)) }

    fun createChannel(c: Context) {
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = c.getSystemService(NotificationManager::class.java)
            val ch = NotificationChannel(CHANNEL, tr("بلاغات المفقودات"), NotificationManager.IMPORTANCE_HIGH)
            ch.description = tr("تنبيه لما حد يلقى أو يضيّع حاجة")
            nm.createNotificationChannel(ch)
            val live = NotificationChannel(CHANNEL_LIVE, tr("التنبيهات الفورية"), NotificationManager.IMPORTANCE_MIN)
            live.description = tr("إشعار صغير دايم عشان التنبيهات توصل بسرعة")
            nm.createNotificationChannel(live)
        }
    }

    fun openIntent(c: Context): PendingIntent = PendingIntent.getActivity(
        c, 0, Intent(c, LoginActivity::class.java),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )

    fun show(c: Context, id: Int, title: String, text: String) {
        if (Build.VERSION.SDK_INT >= 33 &&
            c.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) return
        createChannel(c)
        val n = NotificationCompat.Builder(c, CHANNEL)
            .setSmallIcon(R.drawable.ic_notif)
            .setContentTitle(title)
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setDefaults(Notification.DEFAULT_ALL)
            .setAutoCancel(true)
            .setContentIntent(openIntent(c))
            .build()
        NotificationManagerCompat.from(c).notify(id, n)
    }

    fun schedule(c: Context) {
        if (!enabled(c)) return
        val p = prefs(c)
        if (!p.contains("notif_last")) p.edit().putLong("notif_last", System.currentTimeMillis()).apply()
        val req = PeriodicWorkRequestBuilder<PostWorker>(15, TimeUnit.MINUTES)
            .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
            .build()
        WorkManager.getInstance(c).enqueueUniquePeriodicWork(WORK, ExistingPeriodicWorkPolicy.KEEP, req)
    }

    fun cancel(c: Context) {
        WorkManager.getInstance(c).cancelUniqueWork(WORK)
        prefs(c).edit().remove("notif_last").apply()
    }

    fun lastSeen(c: Context) = prefs(c).getLong("notif_last", System.currentTimeMillis())
    fun setLastSeen(c: Context, v: Long) { prefs(c).edit().putLong("notif_last", v).apply() }

    fun postTitle(p: Post) = tr(if (p.type == TYPE_FOUND) "📦 في زول لقى حاجة" else "🔎 في زول ضاعت منو حاجة")
    fun postText(p: Post) = "${p.title} — ${p.location}\n" + tr("بلّغ: ") + p.authorName
}

/** خدمة بتفضل شغالة وبتسمع Firebase عشان الإشعار يوصل في ثواني. */
class LiveService : Service() {
    private val regs = mutableListOf<ListenerRegistration>()
    private val seen = HashSet<String>()

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        Repo.init(this)
        Notifier.createChannel(this)
        val n = NotificationCompat.Builder(this, Notifier.CHANNEL_LIVE)
            .setSmallIcon(R.drawable.ic_notif)
            .setContentTitle("مفقودات جامعة النيل")
            .setContentText(tr("التنبيهات الفورية شغّالة"))
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_MIN)
            .setContentIntent(Notifier.openIntent(this))
            .build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(77, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        else startForeground(77, n)

        regs.forEach { it.remove() }; regs.clear()
        val uid = FirebaseAuth.getInstance().currentUser?.uid
        if (uid == null || !Notifier.enabled(this)) { stopSelf(); return START_NOT_STICKY }

        val db = FirebaseFirestore.getInstance()
        val since = Notifier.lastSeen(this)

        regs += db.collection("posts").whereGreaterThan("createdAt", since).orderBy("createdAt")
            .addSnapshotListener { snap, _ ->
                if (snap == null) return@addSnapshotListener
                for (ch in snap.documentChanges) {
                    if (ch.type != DocumentChange.Type.ADDED || ch.document.metadata.hasPendingWrites()) continue
                    val p = Post.from(ch.document) ?: continue
                    if (p.authorId == uid || p.status != ST_OPEN || !seen.add(p.id)) continue
                    Notifier.show(this, (p.createdAt % Int.MAX_VALUE).toInt(), Notifier.postTitle(p), Notifier.postText(p))
                    Notifier.setLastSeen(this, maxOf(Notifier.lastSeen(this), p.createdAt))
                }
            }

        regs += db.collection("chats").whereArrayContains("participants", uid)
            .addSnapshotListener { snap, _ ->
                if (snap == null) return@addSnapshotListener
                for (ch in snap.documentChanges) {
                    if (ch.type == DocumentChange.Type.REMOVED || ch.document.metadata.hasPendingWrites()) continue
                    val c = Chat.from(ch.document) ?: continue
                    if (c.lastSender.isEmpty() || c.lastSender == uid || c.lastAt <= since) continue
                    if (Notifier.activeChat == c.id || !seen.add(c.id + c.lastAt)) continue
                    Notifier.show(this, c.id.hashCode(), tr("💬 رسالة جديدة من ") + c.otherName(uid), "${c.postTitle}: ${c.lastMessage}")
                    Notifier.setLastSeen(this, maxOf(Notifier.lastSeen(this), c.lastAt))
                }
            }
        return START_STICKY
    }

    override fun onDestroy() {
        regs.forEach { it.remove() }; regs.clear()
        super.onDestroy()
    }
}

/** احتياط كل 15 دقيقة. */
class PostWorker(ctx: Context, params: WorkerParameters) : Worker(ctx, params) {
    override fun doWork(): Result {
        val c = applicationContext
        Repo.init(c)
        if (!Notifier.enabled(c)) return Result.success()
        val uid = FirebaseAuth.getInstance().currentUser?.uid ?: return Result.success()
        val last = Notifier.lastSeen(c)
        return try {
            val db = FirebaseFirestore.getInstance()
            val snap = Tasks.await(
                db.collection("posts").whereGreaterThan("createdAt", last).orderBy("createdAt").limit(20).get(),
                30, TimeUnit.SECONDS
            )
            val posts = snap.documents.mapNotNull { Post.from(it) }
            val fresh = posts.filter { it.authorId != uid && it.status == ST_OPEN }

            val chatSnap = Tasks.await(
                db.collection("chats").whereArrayContains("participants", uid).limit(50).get(),
                30, TimeUnit.SECONDS
            )
            val chats = chatSnap.documents.mapNotNull { Chat.from(it) }
            val newMsgs = chats.filter { it.lastAt > last && it.lastSender.isNotEmpty() && it.lastSender != uid }

            val newest = maxOf(last, posts.maxOfOrNull { it.createdAt } ?: last, chats.maxOfOrNull { it.lastAt } ?: last)

            fresh.takeLast(5).forEach { p ->
                Notifier.show(c, (p.createdAt % Int.MAX_VALUE).toInt(), Notifier.postTitle(p), Notifier.postText(p))
            }
            newMsgs.take(5).forEach { ch ->
                Notifier.show(c, ch.id.hashCode(), tr("💬 رسالة جديدة من ") + ch.otherName(uid), "${ch.postTitle}: ${ch.lastMessage}")
            }
            Notifier.setLastSeen(c, newest)
            Result.success()
        } catch (e: Exception) {
            Result.retry()
        }
    }
}
