package com.example.unilostandfound

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class PostAdapter(private val onClick: (Post) -> Unit) : RecyclerView.Adapter<PostAdapter.VH>() {
    private var items: List<Post> = emptyList()

    fun submit(list: List<Post>) { items = list; notifyDataSetChanged() }

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val card: View = v.findViewById(R.id.card)
        val avatar: TextView = v.findViewById(R.id.tvAvatar)
        val author: TextView = v.findViewById(R.id.tvAuthor)
        val time: TextView = v.findViewById(R.id.tvTime)
        val badge: TextView = v.findViewById(R.id.tvBadge)
        val title: TextView = v.findViewById(R.id.tvTitle)
        val desc: TextView = v.findViewById(R.id.tvDesc)
        val photo: ImageView = v.findViewById(R.id.ivPhoto)
        val meta: TextView = v.findViewById(R.id.tvMeta)
        val done: TextView = v.findViewById(R.id.tvDone)
        val open: View = v.findViewById(R.id.btnOpen)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        VH(LayoutInflater.from(parent.context).inflate(R.layout.item_post, parent, false))

    override fun getItemCount() = items.size

    override fun onBindViewHolder(h: VH, position: Int) {
        val p = items[position]
        val ctx = h.itemView.context
        h.avatar.text = p.authorName.trim().take(1).ifEmpty { "؟" }
        h.author.text = p.authorName
        h.time.text = timeAgo(p.createdAt)
        h.badge.text = typeLabel(p.type)
        if (p.type == TYPE_LOST) {
            h.badge.setBackgroundResource(R.drawable.bg_badge_lost)
            h.badge.setTextColor(ctx.getColor(R.color.on_mango))
        } else {
            h.badge.setBackgroundResource(R.drawable.bg_badge_found)
            h.badge.setTextColor(ctx.getColor(R.color.title))
        }
        h.title.text = p.title
        h.desc.text = p.description
        h.desc.show(p.description.isNotBlank())
        if (p.photoB64.isNotBlank()) {
            h.photo.show(true); ImageLoader.loadB64(h.photo, p.id, p.photoB64)
        } else { h.photo.tag = null; h.photo.show(false) }
        h.meta.text = "📍 ${p.location}   •   🏷️ ${tr(p.category)}"
        when (p.status) {
            ST_DONE -> {
                h.done.show(true)
                h.done.setBackgroundResource(R.drawable.bg_done)
                h.done.setTextColor(ctx.getColor(R.color.green))
                h.done.text = receivedText(p)
                h.card.alpha = 0.75f
            }
            ST_OFFICE -> {
                h.done.show(true)
                h.done.setBackgroundResource(R.drawable.bg_tip)
                h.done.setTextColor(ctx.getColor(R.color.ink))
                h.done.text = officeText(p)
                h.card.alpha = 1f
            }
            else -> { h.done.show(false); h.card.alpha = 1f }
        }
        h.card.setOnClickListener { onClick(p) }
        h.open.setOnClickListener { onClick(p) }
    }
}
