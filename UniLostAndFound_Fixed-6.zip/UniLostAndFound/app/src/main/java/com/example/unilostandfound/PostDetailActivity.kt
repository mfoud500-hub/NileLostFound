package com.example.unilostandfound

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import androidx.appcompat.app.AppCompatActivity
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.widget.Toolbar
import com.google.android.material.button.MaterialButton
import com.google.firebase.firestore.ListenerRegistration

class PostDetailActivity : BaseActivity() {
    private var postId = ""
    private var post: Post? = null
    private lateinit var me: User
    private var reg: ListenerRegistration? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val u = Session.user
        val id = intent.getStringExtra("id")
        if (u == null || id == null) { finish(); return }
        me = u; postId = id
        setContentView(R.layout.activity_post_detail)
        val tb = findViewById<Toolbar>(R.id.toolbar)
        setSupportActionBar(tb)
        tb.setNavigationOnClickListener { finish() }
    }

    override fun onStart() {
        super.onStart()
        if (postId.isEmpty()) return
        reg = Repo.listenPost(postId) { p ->
            if (p == null) { finish() } else { post = p; invalidateOptionsMenu(); bind(p) }
        }
    }

    override fun onStop() {
        reg?.remove(); reg = null
        super.onStop()
    }

    private fun isAuthor(p: Post) = p.authorId == me.id

    /** مين يقدر يضغط «تأكيد الاستلام»؟ صاحب الغرض بس. */
    private fun canConfirm(p: Post): Boolean {
        if (p.status != ST_OPEN) return false
        return if (p.type == TYPE_FOUND) p.authorId != me.id   // الناشر لقاه، المستلم هو صاحبو
        else p.authorId == me.id                                // الناشر هو صاحب الغرض الضايع
    }

    private fun bind(post: Post) {
        val ivPhoto = findViewById<ImageView>(R.id.ivPhoto)
        if (post.photoB64.isNotBlank()) {
            ivPhoto.show(true); ImageLoader.loadB64(ivPhoto, post.id, post.photoB64)
        } else ivPhoto.show(false)

        val badge = findViewById<TextView>(R.id.tvBadge)
        badge.text = typeLabel(post.type)
        if (post.type == TYPE_LOST) {
            badge.setBackgroundResource(R.drawable.bg_badge_lost); badge.setTextColor(getColor(R.color.on_mango))
        } else {
            badge.setBackgroundResource(R.drawable.bg_badge_found); badge.setTextColor(getColor(R.color.title))
        }
        findViewById<TextView>(R.id.tvTitle).text = post.title
        findViewById<TextView>(R.id.tvInfo).text =
            "🏷️ ${tr(post.category)}\n📍 ${post.location}\n🕒 ${fullDate(post.createdAt)}  (${timeAgo(post.createdAt)})"
        val desc = findViewById<TextView>(R.id.tvDesc)
        desc.text = post.description
        desc.show(post.description.isNotBlank())

        findViewById<TextView>(R.id.tvAvatar).text = post.authorName.trim().take(1).ifEmpty { "؟" }
        findViewById<TextView>(R.id.tvAuthor).text = post.authorName + if (isAuthor(post)) tr("  (إنت)") else ""
        val hasPhone = post.authorPhone.filter { it.isDigit() }.length >= 9
        findViewById<TextView>(R.id.tvPhone).text = tr("التواصل: اتصال • واتساب • شات")
        findViewById<android.view.View>(R.id.contactRow).show(hasPhone && !isAuthor(post))

        findViewById<MaterialButton>(R.id.btnCall).setOnClickListener {
            startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:${post.authorPhone}")))
        }
        findViewById<MaterialButton>(R.id.btnWhatsApp).setOnClickListener {
            val msg = if (Tr.en) "Hello, I am ${me.name} from the Nile University Lost & Found app. Regarding: ${post.title}"
                else "السلام عليكم، أنا ${me.name} من تطبيق مفقودات جامعة النيل. بخصوص: ${post.title}"
            val url = "https://wa.me/${waNumber(post.authorPhone)}?text=${Uri.encode(msg)}"
            try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) }
            catch (e: Exception) { toast("ما قدرنا نفتح واتساب") }
        }

        val btnChat = findViewById<MaterialButton>(R.id.btnChat)
        btnChat.text = tr(if (isAuthor(post)) "💬  شوف الرسائل" else "💬  دردش مع الناشر في التطبيق")
        btnChat.setOnClickListener {
            if (isAuthor(post)) startActivity(Intent(this, ChatsActivity::class.java))
            else Repo.openChat(post, me) { id ->
                startActivity(Intent(this, ChatActivity::class.java)
                    .putExtra("chatId", id).putExtra("name", post.authorName).putExtra("post", post.title))
            }
        }

        val tip = findViewById<TextView>(R.id.tvTip)
        tip.text = tr(when {
            post.status == ST_DONE -> "البلاغ دا خلص ✔️"
            post.status == ST_OFFICE -> "الغرض موجود في مكتب شؤون الطلاب. روح المكتب ووصّف الغرض واثبت إنو بتاعك، وهم بيسلّموه ليك."
            isAuthor(post) && post.type == TYPE_LOST ->
                "الإعلان دا إنت نشرتو. لمّا غرضك يرجع ليك اضغط «تأكيد الاستلام» تحت."
            isAuthor(post) ->
                "الإعلان دا إنت نشرتو. لمّا صاحب الغرض يستلمو بيضغط «تأكيد الاستلام» وإنت بتشوف الحالة هنا."
            post.type == TYPE_FOUND ->
                "دا بتاعك؟ كلّم الناشر وصّف ليهو الغرض وعلامة مميزة فيهو (لون، ماركة، شنو جواهو)، وقابلو جوّه الجامعة. بعد ما تستلم اضغط «تأكيد الاستلام»."
            else ->
                "لقيت الغرض؟ كلّم صاحبو واتأكد إنو بيوصّفو صاح قبل ما تسلّمو. بعد التسليم هو بيضغط «تأكيد الاستلام»."
        })
        tip.show(post.status != ST_DONE)

        val done = findViewById<TextView>(R.id.tvDone)
        when (post.status) {
            ST_DONE -> {
                done.show(true)
                done.setBackgroundResource(R.drawable.bg_done)
                done.setTextColor(getColor(R.color.green))
                done.text = receivedText(post) +
                    (if (post.receivedAt > 0) "\n${fullDate(post.receivedAt)}" else "")
            }
            ST_OFFICE -> {
                done.show(true)
                done.setBackgroundResource(R.drawable.bg_tip)
                done.setTextColor(getColor(R.color.ink))
                done.text = officeText(post) +
                    (if (post.officeAt > 0) "\n${fullDate(post.officeAt)}" else "")
            }
            else -> done.show(false)
        }

        // أزرار شؤون الطلاب (للأدمن بس)
        val btnOffice = findViewById<MaterialButton>(R.id.btnOffice)
        btnOffice.show(me.isAdmin && post.status == ST_OPEN && post.type == TYPE_FOUND)
        btnOffice.setOnClickListener { receiveDialog(this, post.id, me) }
        val btnHandover = findViewById<MaterialButton>(R.id.btnHandover)
        btnHandover.show(me.isAdmin && post.status == ST_OFFICE)
        btnHandover.setOnClickListener { handoverDialog(this, post.id, me) }

        val btn = findViewById<MaterialButton>(R.id.btnConfirm)
        btn.show(canConfirm(post))
        btn.setOnClickListener {
            AlertDialog.Builder(this)
                .setTitle(tr("تأكيد الاستلام ✅"))
                .setMessage(tr("إنت استلمت الغرض فعلاً وتأكدت إنو بتاعك؟ بعد التأكيد البلاغ بيتقفل."))
                .setNegativeButton(tr("لسّه"), null)
                .setPositiveButton(tr("أيوا، استلمت")) { _, _ ->
                    btn.isEnabled = false
                    Repo.confirmReceipt(post.id, me) { ok ->
                        btn.isEnabled = true
                        toast(if (ok) "الحمد لله، اتأكد الاستلام 🎉" else "ما قدرنا نأكّد، اتأكد من النت وجرّب تاني")
                    }
                }.show()
        }
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        val p = post
        if (p != null) {
            menuInflater.inflate(R.menu.menu_detail, menu)
            menu.findItem(R.id.action_delete).isVisible = isAuthor(p) || me.isAdmin
            menu.findItem(R.id.action_report).isVisible = !isAuthor(p)
            Tr.translateMenu(menu)
        }
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == R.id.action_delete) {
            AlertDialog.Builder(this)
                .setTitle(tr("مسح البلاغ"))
                .setMessage(tr("عايز تمسح البلاغ دا؟"))
                .setNegativeButton(tr("لا"), null)
                .setPositiveButton(tr("امسحو")) { _, _ -> Repo.deletePost(postId); finish() }
                .show()
            return true
        }
        if (item.itemId == R.id.action_report) {
            val reasons = listOf("محتوى مسيء", "بلاغ كاذب أو احتيال", "بلاغ مكرر", "سبب آخر")
            AlertDialog.Builder(this)
                .setTitle(tr("سبب الإبلاغ"))
                .setItems(reasons.map { tr(it) }.toTypedArray()) { _, which ->
                    val p = post ?: return@setItems
                    Repo.reportPost(p, me, reasons[which]) { ok ->
                        toast(if (ok) "اتبلّغ للإدارة، شكراً ليك 🙏" else "ما قدرنا ننفّذ الطلب، اتأكد من الصلاحيات والنت")
                    }
                }
                .setNegativeButton(tr("إلغاء"), null).show()
            return true
        }
        return super.onOptionsItemSelected(item)
    }
}


/** شؤون الطلاب (الأدمن): استلام غرض اتسلّم للمكتب، مع تسجيل حالتو. */
fun receiveDialog(a: AppCompatActivity, postId: String, admin: User) {
    val conds = listOf("سليم", "فيه ضرر بسيط", "تالف")
    val group = RadioGroup(a).apply { orientation = RadioGroup.VERTICAL }
    conds.forEachIndexed { i, c -> group.addView(RadioButton(a).apply { text = tr(c); id = 100 + i; isChecked = i == 0 }) }
    val note = EditText(a).apply { hint = tr("ملاحظات (اختياري)") }
    val box = LinearLayout(a).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(56, 24, 56, 8)
        addView(group); addView(note)
    }
    AlertDialog.Builder(a)
        .setTitle(tr("استلام الغرض في شؤون الطلاب"))
        .setView(box)
        .setNegativeButton(tr("إلغاء"), null)
        .setPositiveButton(tr("تأكيد الاستلام")) { _, _ ->
            val idx = (group.checkedRadioButtonId - 100).coerceIn(0, conds.size - 1)
            Repo.receiveAtOffice(postId, admin, conds[idx], note.text.toString().trim()) { ok ->
                a.toast(if (ok) "اتسجّل استلام الغرض في الشؤون ✅" else "ما قدرنا ننفّذ الطلب، اتأكد من الصلاحيات والنت")
            }
        }.show()
}

/** شؤون الطلاب (الأدمن): تسليم الغرض لصاحبو بعد التأكد منو. */
fun handoverDialog(a: AppCompatActivity, postId: String, admin: User) {
    val et = EditText(a).apply { hint = tr("اسم صاحب الغرض أو رقمو الجامعي") }
    val box = LinearLayout(a).apply { setPadding(56, 24, 56, 8); addView(et) }
    AlertDialog.Builder(a)
        .setTitle(tr("تسليم الغرض لصاحبو"))
        .setMessage(tr("اتأكد إنو وصّف الغرض صاح وأثبت إنو بتاعو قبل التسليم."))
        .setView(box)
        .setNegativeButton(tr("إلغاء"), null)
        .setPositiveButton(tr("تم التسليم")) { _, _ ->
            val who = et.text.toString().trim()
            if (who.isEmpty()) { a.toast("اكتب اسم صاحب الغرض أو رقمو الجامعي"); return@setPositiveButton }
            Repo.handover(postId, admin, who) { ok ->
                a.toast(if (ok) "اتسجّل التسليم ✅" else "ما قدرنا ننفّذ الطلب، اتأكد من الصلاحيات والنت")
            }
        }.show()
}
