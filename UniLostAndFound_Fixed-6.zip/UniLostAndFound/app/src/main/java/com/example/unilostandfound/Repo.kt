package com.example.unilostandfound

import android.content.Context
import com.google.firebase.FirebaseNetworkException
import com.google.firebase.FirebaseTooManyRequestsException
import com.google.firebase.auth.EmailAuthProvider
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException
import com.google.firebase.auth.FirebaseAuthInvalidUserException
import com.google.firebase.auth.FirebaseAuthUserCollisionException
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.SetOptions

/** كل الاتصال بـ Firebase (الحسابات + البلاغات) في مكان واحد. */
object Repo {
    private var ctx: Context? = null
    fun init(c: Context) { if (ctx == null) ctx = c.applicationContext; Tr.init(c) }

    private val auth get() = FirebaseAuth.getInstance()
    private val db get() = FirebaseFirestore.getInstance()
    private val prefs get() = ctx!!.getSharedPreferences("unilf_local", Context.MODE_PRIVATE)

    /** الرقم الجامعي بيتحوّل لإيميل داخلي عشان نستخدم Firebase Auth. */
    private fun email(studentNo: String) = "$studentNo@nileuni.app"

    private fun errMsg(e: Exception): String = when (e) {
        is FirebaseAuthUserCollisionException -> "الرقم الجامعي دا مسجّل من قبل"
        is FirebaseAuthInvalidCredentialsException, is FirebaseAuthInvalidUserException ->
            "الرقم الجامعي أو كلمة السر ما صاح يا زول"
        is FirebaseNetworkException -> "ما في نت، اتأكد من الاتصال"
        is FirebaseTooManyRequestsException -> "محاولات كتيرة، استنى شوية وجرّب"
        else -> tr("حصل خطأ: ") + e.message
    }

    // ---------- الحسابات ----------
    fun register(name: String, sno: String, phone: String, pw: String, cb: (User?, String?) -> Unit) {
        auth.createUserWithEmailAndPassword(email(sno), pw)
            .addOnSuccessListener { r ->
                val uid = r.user!!.uid
                val u = User(uid, name, sno, phone)
                db.collection("users").document(uid)
                    .set(mapOf("name" to name, "studentNo" to sno, "phone" to phone))
                    .addOnSuccessListener { Session.user = u; cb(u, null) }
                    .addOnFailureListener { cb(null, "اتسجّل الحساب لكن ما اتحفظت بياناتك، جرّب تدخل تاني") }
            }
            .addOnFailureListener { cb(null, errMsg(it)) }
    }

    fun login(sno: String, pw: String, cb: (User?, String?) -> Unit) {
        auth.signInWithEmailAndPassword(email(sno), pw)
            .addOnSuccessListener { r ->
                loadUser(r.user!!.uid) { u ->
                    if (u == null) cb(null, "ما لقينا بيانات الحساب، جرّب تاني")
                    else if (u.blocked) { auth.signOut(); cb(null, tr("حسابك موقوف، تواصل مع الإدارة")) }
                    else { Session.user = u; cb(u, null) }
                }
            }
            .addOnFailureListener { cb(null, errMsg(it)) }
    }

    fun loadUser(uid: String, cb: (User?) -> Unit) {
        db.collection("users").document(uid).get()
            .addOnSuccessListener { d ->
                cb(if (d.exists()) User(
                    uid, d.getString("name") ?: "", d.getString("studentNo") ?: "", d.getString("phone") ?: "",
                    d.getString("role") == "admin", d.getBoolean("blocked") == true
                ) else null)
            }
            .addOnFailureListener { cb(null) }
    }

    /** لو في جلسة محفوظة من قبل. */
    fun loadCurrentUser(cb: (User?) -> Unit) {
        val uid = auth.currentUser?.uid
        if (uid == null) cb(null)
        else loadUser(uid) { u ->
            if (u != null && u.blocked) { auth.signOut(); cb(null) } else cb(u)
        }
    }

    fun changePassword(old: String, new: String, cb: (String?) -> Unit) {
        val u = auth.currentUser
        val em = u?.email
        if (u == null || em == null) { cb("سجّل دخولك الأول"); return }
        u.reauthenticate(EmailAuthProvider.getCredential(em, old))
            .addOnSuccessListener {
                u.updatePassword(new).addOnSuccessListener { cb(null) }.addOnFailureListener { cb(errMsg(it)) }
            }
            .addOnFailureListener { cb("كلمة السر القديمة ما صاح") }
    }

    fun signOut() { ctx?.let { Notifier.cancel(it); Notifier.stopLive(it) }; auth.signOut(); clearBio(); Session.user = null }

    // ---------- البصمة (محلية على الجهاز) ----------
    fun bioUid(): String? = prefs.getString("bio_uid", null)
    fun setBio(uid: String) { prefs.edit().putString("bio_uid", uid).apply() }
    fun clearBio() { prefs.edit().remove("bio_uid").apply() }

    // ---------- البلاغات ----------
    fun listenPosts(cb: (List<Post>) -> Unit): ListenerRegistration =
        db.collection("posts").orderBy("createdAt", Query.Direction.DESCENDING).limit(100)
            .addSnapshotListener { snap, _ ->
                if (snap != null) cb(snap.documents.mapNotNull { Post.from(it) })
            }

    /** تحديث يدوي: بنجيب البلاغات من السيرفر مباشرة. */
    fun refreshPosts(cb: (List<Post>?) -> Unit) {
        db.collection("posts").orderBy("createdAt", Query.Direction.DESCENDING).limit(100)
            .get(com.google.firebase.firestore.Source.SERVER)
            .addOnSuccessListener { snap -> cb(snap.documents.mapNotNull { Post.from(it) }) }
            .addOnFailureListener { cb(null) }
    }

    fun listenPost(id: String, cb: (Post?) -> Unit): ListenerRegistration =
        db.collection("posts").document(id).addSnapshotListener { d, _ ->
            if (d != null) cb(if (d.exists()) Post.from(d) else null)
        }

    fun addPost(p: Post, onFail: (String) -> Unit) {
        db.collection("posts").add(p.toMap()).addOnFailureListener { onFail(tr("ما اتنشر البلاغ: ") + it.message) }
    }

    fun deletePost(id: String) { db.collection("posts").document(id).delete() }

    fun confirmReceipt(postId: String, me: User, cb: (Boolean) -> Unit) {
        val ref = db.collection("posts").document(postId)
        db.runTransaction { tr ->
            val s = tr.get(ref)
            if (s.getString("status") != ST_OPEN) throw IllegalStateException("done")
            tr.update(ref, mapOf(
                "status" to ST_DONE, "receivedBy" to me.name,
                "receivedById" to me.id, "receivedAt" to System.currentTimeMillis()
            ))
            null
        }.addOnSuccessListener { cb(true) }.addOnFailureListener { cb(false) }
    }

    // ---------- الشات ----------
    /** المحادثة بين الناشر وأي زول تاني بخصوص بلاغ معيّن. */
    fun openChat(post: Post, me: User, cb: (String) -> Unit) {
        val id = "${post.id}_${me.id}"
        val data = mapOf(
            "postId" to post.id, "postTitle" to post.title,
            "userA" to post.authorId, "nameA" to post.authorName,
            "userB" to me.id, "nameB" to me.name,
            "participants" to listOf(post.authorId, me.id)
        )
        db.collection("chats").document(id).set(data, SetOptions.merge())
        cb(id)
    }

    fun listenMessages(chatId: String, cb: (List<Msg>) -> Unit): ListenerRegistration =
        db.collection("chats").document(chatId).collection("messages")
            .orderBy("createdAt", Query.Direction.ASCENDING).limit(300)
            .addSnapshotListener { snap, _ ->
                if (snap != null) cb(snap.documents.map {
                    Msg(it.id, it.getString("senderId") ?: "", it.getString("text") ?: "", it.getLong("createdAt") ?: 0L)
                })
            }

    fun sendMessage(chatId: String, me: User, text: String, onFail: (String) -> Unit) {
        val chatRef = db.collection("chats").document(chatId)
        val msgRef = chatRef.collection("messages").document()
        val now = System.currentTimeMillis()
        val b = db.batch()
        b.set(msgRef, mapOf("senderId" to me.id, "text" to text, "createdAt" to now))
        b.update(chatRef, mapOf("lastMessage" to text, "lastAt" to now, "lastSender" to me.id))
        b.commit().addOnFailureListener { onFail(tr("ما اترسلت الرسالة: ") + it.message) }
    }

    fun listenChats(uid: String, cb: (List<Chat>) -> Unit): ListenerRegistration =
        db.collection("chats").whereArrayContains("participants", uid).limit(100)
            .addSnapshotListener { snap, _ ->
                if (snap != null) cb(snap.documents.mapNotNull { Chat.from(it) }
                    .filter { it.lastAt > 0 }.sortedByDescending { it.lastAt })
            }

    // ---------- الأدمن والإبلاغ ----------
    fun reportPost(post: Post, me: User, reason: String, cb: (Boolean) -> Unit) {
        db.collection("reports").add(mapOf(
            "postId" to post.id, "postTitle" to post.title, "reporterId" to me.id,
            "reporterName" to me.name, "reason" to reason, "createdAt" to System.currentTimeMillis()
        )).addOnSuccessListener { cb(true) }.addOnFailureListener { cb(false) }
    }

    fun listenReports(cb: (List<Report>) -> Unit): ListenerRegistration =
        db.collection("reports").orderBy("createdAt", Query.Direction.DESCENDING).limit(100)
            .addSnapshotListener { snap, _ ->
                if (snap != null) cb(snap.documents.map {
                    Report(it.id, it.getString("postId") ?: "", it.getString("postTitle") ?: "",
                        it.getString("reporterName") ?: "", it.getString("reason") ?: "", it.getLong("createdAt") ?: 0L)
                })
            }

    fun deleteReport(id: String) { db.collection("reports").document(id).delete() }

    fun listUsers(cb: (List<User>?) -> Unit) {
        db.collection("users").limit(300).get()
            .addOnSuccessListener { snap ->
                cb(snap.documents.map {
                    User(it.id, it.getString("name") ?: "", it.getString("studentNo") ?: "", it.getString("phone") ?: "",
                        it.getString("role") == "admin", it.getBoolean("blocked") == true)
                }.sortedBy { it.name })
            }
            .addOnFailureListener { cb(null) }
    }

    fun setBlocked(uid: String, blocked: Boolean, cb: (Boolean) -> Unit) {
        db.collection("users").document(uid).update("blocked", blocked)
            .addOnSuccessListener { cb(true) }.addOnFailureListener { cb(false) }
    }

    // ---------- شؤون الطلاب: استلام وتسليم الأغراض ----------
    fun receiveAtOffice(postId: String, admin: User, condition: String, note: String, cb: (Boolean) -> Unit) {
        val ref = db.collection("posts").document(postId)
        db.runTransaction { t ->
            val s = t.get(ref)
            if (s.getString("status") != ST_OPEN) throw IllegalStateException("not open")
            t.update(ref, mapOf(
                "status" to ST_OFFICE, "officeBy" to admin.name, "officeAt" to System.currentTimeMillis(),
                "officeCondition" to condition, "officeNote" to note
            ))
            null
        }.addOnSuccessListener { cb(true) }.addOnFailureListener { cb(false) }
    }

    fun handover(postId: String, admin: User, ownerInfo: String, cb: (Boolean) -> Unit) {
        val ref = db.collection("posts").document(postId)
        db.runTransaction { t ->
            val s = t.get(ref)
            if (s.getString("status") != ST_OFFICE) throw IllegalStateException("not in office")
            t.update(ref, mapOf(
                "status" to ST_DONE, "receivedBy" to ownerInfo, "receivedById" to admin.id,
                "receivedAt" to System.currentTimeMillis(), "handedBy" to admin.name
            ))
            null
        }.addOnSuccessListener { cb(true) }.addOnFailureListener { cb(false) }
    }

    fun listenOfficePosts(cb: (List<Post>) -> Unit): ListenerRegistration =
        db.collection("posts").whereEqualTo("status", ST_OFFICE)
            .addSnapshotListener { snap, _ ->
                if (snap != null) cb(snap.documents.mapNotNull { Post.from(it) }.sortedByDescending { it.officeAt })
            }
}
