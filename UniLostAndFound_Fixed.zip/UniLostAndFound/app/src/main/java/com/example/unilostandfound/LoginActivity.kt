package com.example.unilostandfound

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import com.google.android.material.textfield.TextInputEditText
import com.google.android.material.textfield.TextInputLayout

class LoginActivity : BaseActivity() {
    private var registerMode = false
    private lateinit var tilName: TextInputLayout
    private lateinit var tilPhone: TextInputLayout
    private lateinit var tilConfirm: TextInputLayout
    private lateinit var etName: TextInputEditText
    private lateinit var etStudent: TextInputEditText
    private lateinit var etPhone: TextInputEditText
    private lateinit var etPassword: TextInputEditText
    private lateinit var etConfirm: TextInputEditText
    private lateinit var tvFormTitle: TextView
    private lateinit var tvToggle: TextView
    private lateinit var btnSubmit: Button
    private lateinit var btnBio: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val cur = Store.currentUser()
        val bioUser = Store.bioUser()
        // لو في جلسة مفتوحة والبصمة مو مفعّلة، ندخل علطول
        if (cur != null && bioUser?.id != cur.id) { goMain(); return }

        setContentView(R.layout.activity_login)
        tilName = findViewById(R.id.tilName)
        tilPhone = findViewById(R.id.tilPhone)
        tilConfirm = findViewById(R.id.tilConfirm)
        etName = findViewById(R.id.etName)
        etStudent = findViewById(R.id.etStudent)
        etPhone = findViewById(R.id.etPhone)
        etPassword = findViewById(R.id.etPassword)
        etConfirm = findViewById(R.id.etConfirm)
        tvFormTitle = findViewById(R.id.tvFormTitle)
        tvToggle = findViewById(R.id.tvToggle)
        btnSubmit = findViewById(R.id.btnSubmit)
        btnBio = findViewById(R.id.btnBio)

        btnSubmit.setOnClickListener { submit() }
        tvToggle.setOnClickListener { registerMode = !registerMode; applyMode() }
        btnBio.setOnClickListener { bioLogin() }
        applyMode()

        if (bioUser != null && biometricAvailable()) {
            btnBio.visibility = View.VISIBLE
            if (savedInstanceState == null) bioLogin()
        }
    }

    private fun applyMode() {
        tilName.show(registerMode); tilPhone.show(registerMode); tilConfirm.show(registerMode)
        tvFormTitle.text = if (registerMode) "سوّي حساب جديد" else "سجّل دخولك"
        btnSubmit.text = if (registerMode) "سجّل" else "دخول"
        tvToggle.text = if (registerMode) "عندك حساب؟ ادخل من هنا" else "ما عندك حساب؟ سجّل هنا"
    }

    private fun bioLogin() {
        val u = Store.bioUser() ?: return
        promptBiometric("ادخل بالبصمة", "حُط صباعك على الحساس") {
            Store.setSession(u.id)
            goMain()
        }
    }

    private fun submit() {
        val sno = etStudent.text.toString().trim()
        val pw = etPassword.text.toString()
        if (sno.length < 3) { toast("اكتب الرقم الجامعي صاح"); return }
        if (registerMode) {
            val name = etName.text.toString().trim()
            val phone = etPhone.text.toString().trim()
            val digits = phone.filter { it.isDigit() }
            when {
                name.length < 3 -> { toast("اكتب اسمك الكامل"); return }
                digits.length < 9 -> { toast("رقم الموبايل ما صاح"); return }
                pw.length < 6 -> { toast("كلمة السر لازم تكون 6 حروف أو أرقام على الأقل"); return }
                pw != etConfirm.text.toString() -> { toast("كلمتين السر ما متطابقات"); return }
            }
            val (u, err) = Store.register(name, sno, phone, pw)
            if (u == null) { toast(err ?: "حصل خطأ، جرّب تاني"); return }
            Store.setSession(u.id)
            afterLogin(u)
        } else {
            val u = Store.login(sno, pw)
            if (u == null) { toast("الرقم الجامعي أو كلمة السر ما صاح يا زول"); return }
            Store.setSession(u.id)
            afterLogin(u)
        }
    }

    private fun afterLogin(u: User) {
        if (biometricAvailable() && Store.bioUser()?.id != u.id) {
            AlertDialog.Builder(this)
                .setTitle("البصمة 👆")
                .setMessage("تحب تدخل بالبصمة المرة الجاية؟")
                .setCancelable(false)
                .setNegativeButton("لا، هسّي") { _, _ -> goMain() }
                .setPositiveButton("أيوا، فعّلها") { _, _ ->
                    promptBiometric("فعّل البصمة", "حُط صباعك للتأكيد", onFail = { goMain() }) {
                        Store.setBioUserId(u.id)
                        toast("اتفعّلت البصمة ✅")
                        goMain()
                    }
                }.show()
        } else goMain()
    }

    private fun goMain() {
        startActivity(Intent(this, MainActivity::class.java))
        finish()
    }
}
