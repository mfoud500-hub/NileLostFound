package com.example.unilostandfound

import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.Menu
import android.view.MenuItem
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.chip.ChipGroup
import com.google.android.material.floatingactionbutton.ExtendedFloatingActionButton

class MainActivity : BaseActivity() {
    private lateinit var adapter: PostAdapter
    private lateinit var etSearch: EditText
    private lateinit var tvStats: TextView
    private lateinit var tvEmpty: TextView
    private var filter = "all"
    private var ready = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Store.currentUser() == null) {
            startActivity(Intent(this, LoginActivity::class.java)); finish(); return
        }
        setContentView(R.layout.activity_main)
        setSupportActionBar(findViewById<Toolbar>(R.id.toolbar))

        etSearch = findViewById(R.id.etSearch)
        tvStats = findViewById(R.id.tvStats)
        tvEmpty = findViewById(R.id.tvEmpty)

        adapter = PostAdapter { post ->
            startActivity(Intent(this, PostDetailActivity::class.java).putExtra("id", post.id))
        }
        findViewById<RecyclerView>(R.id.rvPosts).apply {
            layoutManager = LinearLayoutManager(this@MainActivity)
            adapter = this@MainActivity.adapter
        }

        findViewById<ChipGroup>(R.id.chipGroup).setOnCheckedStateChangeListener { _, ids ->
            filter = when (ids.firstOrNull()) {
                R.id.chipLost -> TYPE_LOST
                R.id.chipFound -> TYPE_FOUND
                R.id.chipDone -> ST_DONE
                else -> "all"
            }
            render()
        }
        etSearch.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) { render() }
            override fun afterTextChanged(s: Editable?) {}
        })
        findViewById<ExtendedFloatingActionButton>(R.id.fabAdd).setOnClickListener {
            startActivity(Intent(this, AddPostActivity::class.java))
        }
        ready = true
    }

    override fun onResume() {
        super.onResume()
        if (ready) render()
    }

    private fun render() {
        val all = Store.posts()
        val q = etSearch.text.toString().trim()
        val list = all.filter { p ->
            val okFilter = when (filter) {
                "all" -> true
                ST_DONE -> p.status == ST_DONE
                else -> p.type == filter && p.status == ST_OPEN
            }
            val hay = "${p.title} ${p.category} ${p.location} ${p.description} ${p.authorName}"
            okFilter && hay.contains(q, ignoreCase = true)
        }.sortedWith(compareBy<Post> { it.status == ST_DONE }.thenByDescending { it.createdAt })

        adapter.submit(list)
        tvEmpty.show(list.isEmpty())
        val open = all.count { it.status == ST_OPEN }
        tvStats.text = "$open بلاغ مفتوح  •  ${all.size - open} اتسلّم"
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.menu_main, menu); return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.action_settings -> startActivity(Intent(this, SettingsActivity::class.java))
            R.id.action_about -> showAbout(this)
            R.id.action_logout -> confirmLogout(this)
        }
        return true
    }
}

fun showAbout(a: AppCompatActivity) {
    AlertDialog.Builder(a)
        .setTitle("مفقودات جامعة النيل 🎓")
        .setMessage("أي حاجة ضاعت منك داخل الجامعة، بلّغ عنها هنا. وأي حاجة لقيتها، انشرها عشان توصل لصاحبها.\n\nصاحب الغرض بيتواصل مع الناشر، بيتأكد منو، وبعد الاستلام بيضغط «تأكيد الاستلام».")
        .setPositiveButton("تمام", null).show()
}

fun confirmLogout(a: AppCompatActivity) {
    AlertDialog.Builder(a)
        .setTitle("تسجيل خروج")
        .setMessage("متأكد عايز تطلع؟")
        .setNegativeButton("لا", null)
        .setPositiveButton("أيوا، اطلع") { _, _ ->
            Store.logout()
            a.startActivity(Intent(a, LoginActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK))
        }.show()
}
