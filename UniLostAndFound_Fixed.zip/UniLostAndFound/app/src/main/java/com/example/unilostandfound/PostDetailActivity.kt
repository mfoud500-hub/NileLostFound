package com.example.unilostandfound

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.widget.Toolbar
import com.google.android.material.button.MaterialButton
import java.io.File

class PostDetailActivity : BaseActivity() {
    private var postId = 0L
    private lateinit var post: Post
    private lateinit var me: User

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val u = Store.currentUser()
        val p = Store.postById(intent.getLongExtra("id", -1L))
        if (u == null || p == null) { finish(); return }
        me = u; post = p; postId = p.id
        setContentView(R.layout.activity_post_detail)
        val tb = findViewById<Toolbar>(R.id.toolbar)
        setSupportActionBar(tb)
        tb.setNavigationOnClickListener { finish() }
        bind()
    }

    private fun isAuthor() = post.authorId == me.id && post.authorId != 0L

    /** مين يقدر يضغط «تأكيد الاستلام»؟ صاحب الغرض بس. */
    private fun canConfirm(): Boolean {
        if (post.status != ST_OPEN) return false
        return when {
            post.authorId == 0L -> true                                   // بلاغات المكتب
            post.type == TYPE_FOUND -> post.authorId != me.id             // لقاه ناشر، المستلم هو صاحبو
            else -> post.authorId == me.id                                // ضاع من الناشر، هو البيستلم
        }
    }

    private fun bind() {
        val ivPhoto = findViewById<ImageView>(R.id.ivPhoto)
        if (post.photoPath.isNotBlank() && File(post.photoPath).exists()) {
            ivPhoto.show(true); ImageLoader.load(ivPhoto, post.photoPath, 1280)
        } else ivPhoto.show(false)

        val badge = findViewById<TextView>(R.id.tvBadge)
        badge.text = typeLabel(post.type)
        if (post.type == TYPE_LOST) {
            badge.setBackgroundResource(R.drawable.bg_badge_lost); badge.setTextColor(getColor(R.color.ink))
        } else {
            badge.setBackgroundResource(R.drawable.bg_badge_found); badge.setTextColor(getColor(R.color.blue_dark))
        }
        findViewById<TextView>(R.id.tvTitle).text = post.title
        findViewById<TextView>(R.id.tvInfo).text =
            "🏷️ ${post.category}\n📍 ${post.location}\n🕒 ${fullDate(post.createdAt)}  (${timeAgo(post.createdAt)})"
        val desc = findViewById<TextView>(R.id.tvDesc)
        desc.text = post.description
        desc.show(post.description.isNotBlank())

        findViewById<TextView>(R.id.tvAvatar).text = post.authorName.trim().take(1).ifEmpty { "؟" }
        findViewById<TextView>(R.id.tvAuthor).text = post.authorName + if (isAuthor()) "  (إنت)" else ""
        val hasPhone = post.authorPhone.filter { it.isDigit() }.length >= 9
        findViewById<TextView>(R.id.tvPhone).text =
            if (hasPhone) post.authorPhone else "تواصل معاهم في مكتب شؤون الطلاب"
        findViewById<android.view.View>(R.id.contactRow).show(hasPhone && !isAuthor())

        findViewById<MaterialButton>(R.id.btnCall).setOnClickListener {
            startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:${post.authorPhone}")))
        }
        findViewById<MaterialButton>(R.id.btnWhatsApp).setOnClickListener {
            val msg = "السلام عليكم، أنا ${me.name} من تطبيق مفقودات جامعة النيل. بخصوص: ${post.title}"
            val url = "https://wa.me/${waNumber(post.authorPhone)}?text=${Uri.encode(msg)}"
            try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) }
            catch (e: Exception) { toast("ما قدرنا نفتح واتساب") }
        }

        val tip = findViewById<TextView>(R.id.tvTip)
        tip.text = when {
            post.status == ST_DONE -> "البلاغ دا خلص ✔️"
            isAuthor() && post.type == TYPE_LOST ->
                "الإعلان دا إنت نشرتو. لمّا غرضك يرجع ليك اضغط «تأكيد الاستلام» تحت."
            isAuthor() ->
                "الإعلان دا إنت نشرتو. لمّا صاحب الغرض يستلمو بيضغط «تأكيد الاستلام» وإنت بتشوف الحالة هنا."
            post.type == TYPE_FOUND ->
                "دا بتاعك؟ كلّم الناشر وصّف ليهو الغرض وعلامة مميزة فيهو (لون، ماركة، شنو جواهو)، وقابلو جوّه الجامعة. بعد ما تستلم اضغط «تأكيد الاستلام»."
            else ->
                "لقيت الغرض؟ كلّم صاحبو واتأكد إنو بيوصّفو صاح قبل ما تسلّمو. بعد التسليم هو بيضغط «تأكيد الاستلام»."
        }
        tip.show(post.status == ST_OPEN)

        val done = findViewById<TextView>(R.id.tvDone)
        if (post.status == ST_DONE) {
            done.show(true)
            done.text = "✅ اتسلّم" + (if (post.receivedBy.isNotBlank()) " لـ ${post.receivedBy}" else "") +
                (if (post.receivedAt > 0) "\n${fullDate(post.receivedAt)}" else "")
        } else done.show(false)

        val btn = findViewById<MaterialButton>(R.id.btnConfirm)
        btn.show(canConfirm())
        btn.setOnClickListener {
            AlertDialog.Builder(this)
                .setTitle("تأكيد الاستلام ✅")
                .setMessage("إنت استلمت الغرض فعلاً وتأكدت إنو بتاعك؟ بعد التأكيد البلاغ بيتقفل.")
                .setNegativeButton("لسّه", null)
                .setPositiveButton("أيوا، استلمت") { _, _ ->
                    post.status = ST_DONE
                    post.receivedBy = me.name
                    post.receivedAt = System.currentTimeMillis()
                    Store.updatePost(post)
                    toast("الحمد لله، اتأكد الاستلام 🎉")
                    invalidateOptionsMenu()
                    bind()
                }.show()
        }
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        if (isAuthor()) menuInflater.inflate(R.menu.menu_detail, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == R.id.action_delete) {
            AlertDialog.Builder(this)
                .setTitle("مسح البلاغ")
                .setMessage("عايز تمسح البلاغ دا؟")
                .setNegativeButton("لا", null)
                .setPositiveButton("امسحو") { _, _ -> Store.deletePost(postId); finish() }
                .show()
            return true
        }
        return super.onOptionsItemSelected(item)
    }
}
