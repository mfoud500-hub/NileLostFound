package com.example.unilostandfound

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.security.SecureRandom
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

const val TYPE_LOST = "lost"
const val TYPE_FOUND = "found"
const val ST_OPEN = "open"
const val ST_DONE = "done"

data class User(
    val id: Long, val name: String, val studentNo: String,
    val phone: String, val salt: String, val hash: String
) {
    fun toJson() = JSONObject().apply {
        put("id", id); put("name", name); put("studentNo", studentNo)
        put("phone", phone); put("salt", salt); put("hash", hash)
    }

    companion object {
        fun fromJson(o: JSONObject) = User(
            o.optLong("id"), o.optString("name"), o.optString("studentNo"),
            o.optString("phone"), o.optString("salt"), o.optString("hash")
        )
    }
}

data class Post(
    val id: Long, val authorId: Long, val authorName: String, val authorPhone: String,
    val type: String, val title: String, val category: String, val location: String,
    val createdAt: Long, val description: String, val photoPath: String,
    var status: String = ST_OPEN, var receivedBy: String = "", var receivedAt: Long = 0L
) {
    fun toJson() = JSONObject().apply {
        put("id", id); put("authorId", authorId); put("authorName", authorName)
        put("authorPhone", authorPhone); put("type", type); put("title", title)
        put("category", category); put("location", location); put("createdAt", createdAt)
        put("description", description); put("photoPath", photoPath); put("status", status)
        put("receivedBy", receivedBy); put("receivedAt", receivedAt)
    }

    companion object {
        fun fromJson(o: JSONObject) = Post(
            o.optLong("id"), o.optLong("authorId"), o.optString("authorName"),
            o.optString("authorPhone"), o.optString("type", TYPE_LOST), o.optString("title"),
            o.optString("category"), o.optString("location"), o.optLong("createdAt"),
            o.optString("description"), o.optString("photoPath"),
            o.optString("status", ST_OPEN), o.optString("receivedBy"), o.optLong("receivedAt")
        )
    }
}

/** تخزين محلي على الجهاز (SharedPreferences). */
object Store {
    private var ctx: Context? = null
    fun init(c: Context) { if (ctx == null) ctx = c.applicationContext }
    private val prefs: SharedPreferences
        get() = ctx!!.getSharedPreferences("unilf_store_v2", Context.MODE_PRIVATE)

    // ---------- كلمة السر ----------
    private fun newSalt(): String {
        val b = ByteArray(16); SecureRandom().nextBytes(b)
        return b.joinToString("") { "%02x".format(it) }
    }

    private fun hashPw(pw: String, salt: String): String {
        val spec = PBEKeySpec(pw.toCharArray(), salt.toByteArray(), 10000, 256)
        val key = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA1").generateSecret(spec).encoded
        return key.joinToString("") { "%02x".format(it) }
    }

    // ---------- المستخدمين ----------
    private fun users(): MutableList<User> {
        val raw = prefs.getString("users_json", null) ?: return mutableListOf()
        return try {
            val a = JSONArray(raw)
            MutableList(a.length()) { User.fromJson(a.getJSONObject(it)) }
        } catch (e: Exception) { mutableListOf() }
    }

    private fun saveUsers(list: List<User>) {
        val a = JSONArray(); list.forEach { a.put(it.toJson()) }
        prefs.edit().putString("users_json", a.toString()).apply()
    }

    fun register(name: String, studentNo: String, phone: String, password: String): Pair<User?, String?> {
        val list = users()
        if (list.any { it.studentNo == studentNo }) return Pair(null, "الرقم الجامعي دا مسجّل من قبل")
        val salt = newSalt()
        val u = User((list.maxOfOrNull { it.id } ?: 0L) + 1L, name, studentNo, phone, salt, hashPw(password, salt))
        list.add(u); saveUsers(list)
        return Pair(u, null)
    }

    fun login(studentNo: String, password: String): User? {
        val u = users().firstOrNull { it.studentNo == studentNo } ?: return null
        return if (hashPw(password, u.salt) == u.hash) u else null
    }

    fun changePassword(user: User, old: String, new: String): Boolean {
        val list = users()
        val i = list.indexOfFirst { it.id == user.id }
        if (i < 0 || hashPw(old, list[i].salt) != list[i].hash) return false
        val salt = newSalt()
        list[i] = list[i].copy(salt = salt, hash = hashPw(new, salt))
        saveUsers(list)
        return true
    }

    fun userById(id: Long): User? = users().firstOrNull { it.id == id }

    // ---------- الجلسة والبصمة ----------
    fun currentUser(): User? = prefs.getLong("session_uid", 0L).takeIf { it > 0 }?.let { userById(it) }
    fun setSession(id: Long) { prefs.edit().putLong("session_uid", id).apply() }
    fun logout() { prefs.edit().remove("session_uid").apply() }

    fun bioUser(): User? = prefs.getLong("bio_uid", 0L).takeIf { it > 0 }?.let { userById(it) }
    fun setBioUserId(id: Long) { prefs.edit().putLong("bio_uid", id).apply() }
    fun clearBio() { prefs.edit().remove("bio_uid").apply() }

    // ---------- البلاغات ----------
    fun posts(): MutableList<Post> {
        if (!prefs.contains("posts_json")) { seed() }
        val raw = prefs.getString("posts_json", null) ?: return mutableListOf()
        return try {
            val a = JSONArray(raw)
            MutableList(a.length()) { Post.fromJson(a.getJSONObject(it)) }
        } catch (e: Exception) { mutableListOf() }
    }

    private fun savePosts(list: List<Post>) {
        val a = JSONArray(); list.forEach { a.put(it.toJson()) }
        prefs.edit().putString("posts_json", a.toString()).apply()
    }

    private fun seed() {
        val now = System.currentTimeMillis()
        val h = 3600_000L
        savePosts(listOf(
            Post(1, 0, "مكتب شؤون الطلاب", "", TYPE_FOUND, "بطاقة جامعية", "بطاقة جامعية", "مبنى الحاسوب",
                now - 5 * h, "لقينا بطاقة جامعية قريب من القاعات. تعال وصّفها وخُدها.", ""),
            Post(2, 0, "الأمن الجامعي", "", TYPE_FOUND, "مفاتيح", "مفاتيح", "كلية الطب",
                now - 28 * h, "مجموعة مفاتيح اتلقت عند المدخل.", ""),
            Post(3, 0, "مكتب شؤون الطلاب", "", TYPE_LOST, "شاحن لابتوب", "إلكترونيات", "مكتبة الجامعة",
                now - 52 * h, "شاحن أسود ضاع في المكتبة، لو شفتو بلّغنا.", "")
        ))
    }

    fun postById(id: Long): Post? = posts().firstOrNull { it.id == id }
    fun nextPostId(): Long = (posts().maxOfOrNull { it.id } ?: 0L) + 1L

    fun addPost(p: Post) { val l = posts(); l.add(0, p); savePosts(l) }

    fun updatePost(p: Post) {
        val l = posts(); val i = l.indexOfFirst { it.id == p.id }
        if (i >= 0) { l[i] = p; savePosts(l) }
    }

    fun deletePost(id: Long) {
        val l = posts()
        l.firstOrNull { it.id == id }?.photoPath?.takeIf { it.isNotBlank() }?.let { File(it).delete() }
        l.removeAll { it.id == id }
        savePosts(l)
    }
}
